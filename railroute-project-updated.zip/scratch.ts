import { config } from 'dotenv';
import { configure, searchTrainBetweenStations, getAvailability } from 'irctc-connect';

config({ path: '.env.local' });

if (!process.env.IRCTC_API_KEY) {
  throw new Error('Set IRCTC_API_KEY in .env.local before running this script.');
}

configure(process.env.IRCTC_API_KEY);

async function test() {
  console.log('--- Search Direct ---');
  try {
    const searchRes = await searchTrainBetweenStations('PNBE', 'BHL', '23-07-2026');
    console.log(JSON.stringify(searchRes?.data?.[0] || searchRes?.[0] || searchRes, null, 2));

    const trainNo = searchRes?.data?.[0]?.train_number || searchRes?.[0]?.train_number;
    if (trainNo) {
      console.log('\n--- Availability ---');
      const availRes = await getAvailability(trainNo, 'PNBE', 'BHL', '23-07-2026', '3A', 'GN');
      console.log(JSON.stringify(availRes, null, 2));
    }
  } catch (e) {
    console.error(e);
  }
}

test();
