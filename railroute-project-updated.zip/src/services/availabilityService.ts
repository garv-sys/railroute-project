import { z } from "zod";

import { checkSeatAvailability } from "@/services/irctcService";
import { buildTrustMeta, type TrustMeta } from "@/lib/confidence";
import {
  availabilityReasonForStatus,
  fareReasonForStatus,
  lookupStatusFromReason,
  makeLookupProof,
  type LookupProof,
  type LookupTrustStatus,
} from "@/lib/railway-trust";

export const ALL_STANDARD_CLASSES = ["1A", "2A", "3A", "3E", "SL", "2S", "CC", "EC", "FC"] as const;

export const availabilityRequestSchema = z.object({
  trainNo: z.string().trim().regex(/^\d{5}$/, "Train number must be 5 digits"),
  source: z.string().trim().min(2).transform((value) => value.toUpperCase()),
  destination: z.string().trim().min(2).transform((value) => value.toUpperCase()),
  date: z.string().trim().min(8),
  classType: z.string().trim().min(1).transform((value) => value.toUpperCase()).default("3A"),
  quota: z.string().trim().min(1).transform((value) => value.toUpperCase()).default("GN"),
});

export type AvailabilityRequest = z.infer<typeof availabilityRequestSchema>;

export type VerifiedAvailabilityStatus = "AVAILABLE" | "RAC" | "WL" | "REGRET" | "UNAVAILABLE";

export type VerifiedAvailability = {
  trainNo: string;
  source: string;
  destination: string;
  date: string;
  classType: string;
  quota: string;
  availabilityText: string | null;
  status: VerifiedAvailabilityStatus;
  seats: number | null;
  availabilitySource: "date-specific-provider" | "unavailable";
  fare: number | null;
  fareSource: "date-specific-provider" | "unavailable";
  fareExactRequest: boolean;
  exactDate: boolean;
  availabilityStatus: LookupTrustStatus;
  fareStatus: LookupTrustStatus;
  lookupReason: string;
  proof: LookupProof;
  reason?: string;
  provider: string;
  rawAvailabilityRows: any[];
  providerFare: any;
};

export type AvailabilityServiceResult = {
  success: boolean;
  data: VerifiedAvailability;
  meta: TrustMeta;
  provider: string;
  rawProviderResponse?: any;
};

export function fareNumber(value: unknown) {
  const amount = Number(String(value || "").replace(/[^\d.]/g, ""));
  return Number.isFinite(amount) && amount > 0 ? amount : 0;
}

function normalizedDateParts(value: unknown) {
  const raw = String(value || "").trim().replace(/\s+/g, "").replace(/\//g, "-");
  if (!raw) return null;
  const parts = raw.split("-");
  if (parts.length !== 3) return null;
  if (parts[0]?.length === 4) {
    const [year, month, day] = parts;
    return {
      day: String(Number(day)).padStart(2, "0"),
      month: String(Number(month)).padStart(2, "0"),
      year,
    };
  }
  const [day, month, year] = parts;
  return {
    day: String(Number(day)).padStart(2, "0"),
    month: String(Number(month)).padStart(2, "0"),
    year,
  };
}

export function dateMatchesProviderRow(itemDate: unknown, requestedDate: string) {
  const item = normalizedDateParts(itemDate);
  const requested = normalizedDateParts(requestedDate);
  if (!item || !requested) return false;
  return item.day === requested.day && item.month === requested.month && item.year === requested.year;
}

export function classifyAvailability(rawStatus: unknown): { status: VerifiedAvailabilityStatus; seats: number | null; text: string | null } {
  const text = String(rawStatus || "").trim();
  if (!text) return { status: "UNAVAILABLE", seats: null, text: null };

  const compact = text.toUpperCase().replace(/\s+/g, "");
  const match = compact.match(/\d+/);
  const seats = match ? Number(match[0]) : null;

  if (compact.includes("TRAINNOTONSCHEDULEDDATE") || compact.includes("NOTAVAILABLE")) return { status: "UNAVAILABLE", seats: null, text };
  if (compact.includes("REGRET")) return { status: "REGRET", seats, text };
  if (compact.includes("RAC")) return { status: "RAC", seats, text };
  if (compact.includes("WL") || compact.includes("WAITLIST")) return { status: "WL", seats, text };
  if (compact.includes("AVAILABLE") || compact.includes("CURR_AV") || /\bAVL/.test(compact)) return { status: "AVAILABLE", seats, text };
  return { status: "UNAVAILABLE", seats: null, text };
}

function fareFromProviderResponse(response: any) {
  const fare = response?.data?.fare ?? response?.fare;
  const candidates = [
    fare?.totalFare,
    fare?.TotalFare,
    fare?.Fare,
    fare?.Amount,
    fare?.total,
    fare,
  ];
  for (const candidate of candidates) {
    const amount = fareNumber(candidate);
    if (amount > 0) return amount;
  }
  return 0;
}

function unavailableResult(
  params: AvailabilityRequest,
  provider: string,
  reason: string,
  rawProviderResponse?: any,
  partial: { fare?: number; providerFare?: any; rawAvailabilityRows?: any[]; exactDate?: boolean } = {}
): AvailabilityServiceResult {
  const exactDate = Boolean(partial.exactDate);
  const fare = exactDate && partial.fare && partial.fare > 0 ? partial.fare : null;
  const availabilityStatus = lookupStatusFromReason(reason);
  const fareStatus: LookupTrustStatus = fare && exactDate ? "VERIFIED" : availabilityStatus;
  const proof = makeLookupProof(params);
  const data: VerifiedAvailability = {
    ...params,
    availabilityText: null,
    status: "UNAVAILABLE",
    seats: null,
    availabilitySource: "unavailable",
    fare,
    fareSource: fare && exactDate ? "date-specific-provider" : "unavailable",
    fareExactRequest: Boolean(fare && exactDate),
    exactDate,
    availabilityStatus,
    fareStatus,
    lookupReason: availabilityReasonForStatus(availabilityStatus, params.classType, reason),
    proof,
    reason,
    provider,
    rawAvailabilityRows: partial.rawAvailabilityRows || [],
    providerFare: partial.providerFare ?? null,
  };

  const hasFare = Boolean(fare && exactDate);
  return {
    success: true,
    data,
    provider,
    rawProviderResponse,
    meta: buildTrustMeta({
      source: hasFare ? "live" : "unavailable",
      provider,
      isLive: hasFare,
      warning: [
        availabilityReasonForStatus(availabilityStatus, params.classType, reason),
        hasFare ? undefined : fareReasonForStatus(fareStatus, reason),
      ].filter(Boolean).join(" "),
    }),
  };
}

export async function getVerifiedAvailability(input: unknown): Promise<AvailabilityServiceResult> {
  const params = availabilityRequestSchema.parse(input);
  let response: any;

  try {
    response = await checkSeatAvailability(
      params.trainNo,
      params.source,
      params.destination,
      params.date,
      params.classType,
      params.quota
    );
  } catch (error: any) {
    return unavailableResult(params, "irctc-connect", error?.message || "Provider request failed");
  }

  const provider = response?.provider || "irctc-connect";
  if (!response || response.success === false) {
    return unavailableResult(params, provider, response?.error || "Provider did not return availability", response);
  }

  const rows = Array.isArray(response?.data?.availability) ? response.data.availability : [];
  const fare = fareFromProviderResponse(response);
  const providerFare = response?.data?.fare ?? response?.fare ?? null;
  const exactDateRow = rows.find((row: any) => dateMatchesProviderRow(row?.date || row?.JourneyDate, params.date));
  if (!exactDateRow) {
    return unavailableResult(
      params,
      provider,
      rows.length
        ? "Provider returned availability rows, but none matched the selected journey date"
        : "Provider did not return availability rows",
      response,
      // The provider can return a fare object even when no availability row
      // matches the selected journey date. Keep that fare in debug only; do
      // not render it as selected-date fare.
      { providerFare, rawAvailabilityRows: rows }
    );
  }

  const rawStatus = exactDateRow.availabilityText || exactDateRow.status || exactDateRow.Availability;
  const classified = classifyAvailability(rawStatus);
  if (!classified.text || classified.status === "UNAVAILABLE") {
    return unavailableResult(
      params,
      provider,
      "Provider did not return a usable availability status for the selected date",
      response,
      { fare, providerFare, rawAvailabilityRows: rows, exactDate: true }
    );
  }

  const data: VerifiedAvailability = {
    ...params,
    availabilityText: classified.text,
    status: classified.status,
    seats: classified.seats,
    availabilitySource: "date-specific-provider",
    fare: fare > 0 ? fare : null,
    fareSource: fare ? "date-specific-provider" : "unavailable",
    fareExactRequest: Boolean(fare),
    exactDate: true,
    availabilityStatus: "VERIFIED",
    fareStatus: fare ? "VERIFIED" : "PROVIDER_UNAVAILABLE",
    lookupReason: fare
      ? "Provider returned availability and fare for the exact selected request."
      : "Provider returned availability for the selected date, but did not return fare.",
    proof: makeLookupProof(params),
    provider,
    rawAvailabilityRows: rows,
    providerFare,
  };

  return {
    success: true,
    data,
    provider,
    rawProviderResponse: response,
    meta: buildTrustMeta({
      source: "live",
      provider,
      isLive: true,
      warning: fare ? undefined : "Provider returned availability for the selected date, but no fare.",
    }),
  };
}
