"use client";

import React, { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Train, ArrowRight, Clock, Sparkles, MapPin, Calendar,
  Coffee, ChevronRight, Info, ArrowLeft, Compass, Search,
  CheckCircle2, ChevronDown, Moon, Sun, ShieldCheck,
  ArrowLeftRight, ExternalLink, Copy, User,
  LogOut, X, Activity, Lock, Mail, Key, Shield, Laptop,
  Database, Cpu, Grid, Navigation, Loader2, AlertCircle,
  Play, Square, Star, HelpCircle, StarHalf
} from "lucide-react";
import Link from "next/link";
import { STATION_GEO } from "@/components/india-route-map";
import allStationsRaw from "@/data/all_stations.json";
import { getAirDistance } from "@/services/trainService";
import dynamic from "next/dynamic";

const IndiaRouteMap = dynamic(() => import("@/components/india-route-map"), { ssr: false });

// ═══════════════════════════════════════════
// TYPES & ENUMS
// ═══════════════════════════════════════════

interface RawStation { code: string; name: string; }

interface RouteLeg {
  type: "train" | "transfer";
  name?: string;
  number?: string;
  from: string;
  to: string;
  depTime?: string;
  arrTime?: string;
  platform?: string;
  duration: string;
  price?: number;
  classType?: string;
  layoverReason?: string;
}

interface TrainRoute {
  id: string;
  name: string;
  type: "direct" | "split";
  preview: string[];
  totalDuration: string;
  transfers: number;
  price: number;
  classes: string[];
  isRecommended?: boolean;
  tag?: string;
  legs: RouteLeg[];
  stationCodes: string[];
  rating?: number;
  features?: string[];
  cleanlinessScore?: number;
  punctualityScore?: number;
  availability?: string;
  confirmationChance?: string | number;
}

// ═══════════════════════════════════════════
// STATION & ROUTE DATA & ALIASES
// ═══════════════════════════════════════════

const allStations: RawStation[] = allStationsRaw as RawStation[];

const STATION_DETAILS: Record<string, { name: string }> = {
  'PNBE': { name: 'Patna Junction' },
  'PPTA': { name: 'Patliputra Junction' },
  'DNR':  { name: 'Danapur' },
  'RJPB': { name: 'Rajendra Nagar Terminal' },
  'NDLS': { name: 'New Delhi' },
  'NZM':  { name: 'Hazrat Nizamuddin' },
  'ANVT': { name: 'Anand Vihar Terminal' },
  'DLI':  { name: 'Old Delhi Junction' },
  'MAS':  { name: 'Chennai Central' },
  'PER':  { name: 'Perambur' },
  'MS':   { name: 'Chennai Egmore' },
  'JP':   { name: 'Jaipur Junction' },
  'DDU':  { name: 'Pt. Deen Dayal Upadhyaya Junction' },
  'PRYJ': { name: 'Prayagraj Junction' },
  'CNB':  { name: 'Kanpur Central' },
  'BSB':  { name: 'Varanasi Junction' },
  'LKO':  { name: 'Lucknow Charbagh' },
  'BPL':  { name: 'Bhopal Junction' },
  'NGP':  { name: 'Nagpur Junction' },
  'ET':   { name: 'Itarsi Junction' },
  'JBP':  { name: 'Jabalpur Junction' },
  'SML':  { name: 'Shimla' },
  'KLK':  { name: 'Kalka Junction' },
  'CDG':  { name: 'Chandigarh' },
  'UMB':  { name: 'Ambala Cantonment' },
  'LDH':  { name: 'Ludhiana Junction' },
  'DJJ':  { name: 'Darjeeling' },
  'NJP':  { name: 'New Jalpaiguri' },
  'SVDK': { name: 'Shri Mata Vaishno Devi Katra' },
  'JAT':  { name: 'Jammu Tawi' },
  'MTP':  { name: 'Mettupalayam' },
  'UAM':  { name: 'Udagamandalam (Ooty)' },
  'MAO':  { name: 'Madgaon (Goa)' },
  'VSG':  { name: 'Vasco da Gama (Goa)' },
  'HWH':  { name: 'Howrah Junction' },
  'SDAH': { name: 'Sealdah Junction' },
  'SC':   { name: 'Secunderabad Junction' },
  'HYB':  { name: 'Hyderabad Deccan' },
  'HJP':  { name: 'Hajipur Junction' },
};

const STATE_STATIONS: Record<string, string[]> = {
  bihar: ["PNBE", "PPTA", "DNR", "RJPB", "ARA", "GAYA", "BGP", "MFP", "SPJ", "CPR", "HJP", "KIR", "BJU", "DBG", "PNC", "SV", "DDU"],
  up: ["LKO", "CNB", "BSB", "BSBS", "DDU", "PRYJ", "AGC", "AF", "GZB", "GKP", "ALD", "BE", "MB", "AY", "AYC", "JNU", "VGLJ", "MTJ", "AMRO", "AMV"],
  "uttar pradesh": ["LKO", "CNB", "BSB", "BSBS", "DDU", "PRYJ", "AGC", "AF", "GZB", "GKP", "ALD", "BE", "MB", "AY", "AYC", "JNU", "VGLJ", "MTJ", "AMRO", "AMV"],
  rajasthan: ["JP", "AII", "KOTA", "JU", "BKI", "FL", "BHL", "COR", "NMH", "MDS", "RTM"],
  delhi: ["NDLS", "NZM", "ANVT", "DLI", "DEC", "SZM"],
  maharashtra: ["CSMT", "LTT", "BDTS", "BVI", "MMCT", "PUNE", "NGP", "KYN", "TNA", "DR", "DDR"],
  gujarat: ["ADI", "BRC", "ST", "RJT", "HAPA", "JAM", "VAPI", "ANND", "NVS", "BH"]
};

const STATION_ALIASES: Record<string, string> = {
  "ptna": "PNBE",
  "patna": "PNBE",
  "panta": "PNBE",
  "ahmedbad": "ADI",
  "ahmedabad": "ADI",
  "ahm": "ADI",
  "ahd": "ADI",
  "indore": "INDB",
  "indr": "INDB",
  "indo": "INDB",
  "up": "LKO",
  "bihar": "PNBE",
  "kolkata": "HWH",
  "calcutta": "HWH",
  "koala": "KOAA",
  "koaa": "KOAA",
  "hwh": "HWH",
  "ara": "ARA",
  "mumbai": "CSMT",
  "bombay": "CSMT",
  "delhi": "NDLS",
  "del": "NDLS",
  "jaipur": "JP",
  "jpr": "JP"
};

// ═══════════════════════════════════════════
// HELPER METHODS
// ═══════════════════════════════════════════

function getStationCoords(code: string): [number, number] {
  const c = code.toUpperCase().trim();
  if (STATION_GEO[c]) return STATION_GEO[c];
  
  let hash = 5381;
  for (let i = 0; i < c.length; i++) {
    hash = ((hash << 5) + hash) + c.charCodeAt(i);
  }
  const lat = 12.0 + (Math.abs(hash) % 180) / 10.0;
  const lng = 72.0 + (Math.abs(hash >> 5) % 140) / 10.0;
  return [lat, lng];
}

function buildRouteCoords(codes: string[]) {
  return codes.map(code => {
    const [lat, lng] = getStationCoords(code);
    const st = allStations.find(s => s.code === code);
    return { code, name: st?.name || code, lat, lng };
  });
}

function getStationName(code: string, fallbackName: string) {
  const c = code.toUpperCase().trim();
  if (STATION_DETAILS[c]) return STATION_DETAILS[c].name;
  const found = allStations.find(s => s.code.toUpperCase() === c);
  if (found) return found.name;
  return fallbackName;
}

function parseDurationToMinutes(durationStr: string): number {
  if (!durationStr) return 0;
  let totalMins = 0;
  const parts = durationStr.split("+");
  for (const part of parts) {
    const hrsMatch = part.match(/(\d+)\s*h/i);
    const minsMatch = part.match(/(\d+)\s*m/i);
    const hrs = hrsMatch ? parseInt(hrsMatch[1], 10) : 0;
    const mins = minsMatch ? parseInt(minsMatch[1], 10) : 0;
    totalMins += (hrs * 60) + mins;
  }
  return totalMins;
}

function getRouteTotalDurationMinutes(r: TrainRoute): number {
  let total = 0;
  for (const leg of r.legs) {
    if (leg.duration) {
      total += parseDurationToMinutes(leg.duration);
    }
  }
  return total;
}

function getStateForStation(code: string, name: string): string {
  const c = (code || "").toUpperCase().trim();
  const n = (name || "").toUpperCase().trim();

  if (["SHC", "SBV", "MNE", "KGG", "BGS", "BJU", "PNBE", "HJP", "PPTA", "RJPB", "DNR", "GAYA", "BKP", "MKA", "KIUL", "JMUI", "JAJ", "BGP", "JMP", "KIR", "MFP", "SPJ", "DBG", "SGG", "MNE"].includes(c)) return "Bihar";
  if (["NDLS", "DLI", "NZM", "ANVT", "DEC", "SZM", "SSB"].includes(c)) return "Delhi";
  if (["CNB", "PRYJ", "LKO", "BSB", "DDU", "GKP", "AGC", "VGLJ", "JHS", "ALJN", "GZB", "TDL", "ETW", "MZP", "FTP", "KLD", "BST", "GD", "BBK", "SPN", "BE", "MB", "HRI", "HAP", "AMRO", "BLM", "SLN", "MBLP", "NHH", "MFKA", "AKJ", "HGH", "AY", "AYC", "FD"].includes(c)) return "Uttar Pradesh";
  if (["HWH", "SDAH", "KOAA", "SHM", "ASN", "DGR", "BWN", "NJP", "MLDT", "RPH", "KGP", "ADRA", "BOY", "BDC", "SRC", "ULB", "MCA", "PKU", "JGM", "CKU"].includes(c)) return "West Bengal";
  if (["JP", "JU", "AII", "UDZ", "BKI", "FL", "REER", "DO", "GADJ", "ASV", "BME", "ABR", "MJ", "SOD", "HP", "RKB", "BGKT", "KOTA", "SGNR"].includes(c)) return "Rajasthan";
  if (["KLK", "CDG", "UMB", "RE", "GGN", "PNP", "KKDE", "ROK", "JIND", "JHL", "BGZ"].includes(c)) return "Haryana";
  if (["SML", "SOL", "DMP", "BOF", "TTR"].includes(c)) return "Himachal Pradesh";
  if (["GADA", "ADI", "SRGT", "BRC", "ST", "RJT", "HAPA", "JAM", "DWK", "VRL", "BH", "ANND", "ND", "UDN", "VYA", "USD"].includes(c)) return "Gujarat";
  if (["CSMT", "LTT", "BDTS", "BVI", "MMCT", "PUNE", "DD", "SUR", "NGP", "BSL", "NK", "IGP", "KYN", "TNA", "DR", "DDR"].includes(c)) return "Maharashtra";
  if (["DHN", "JSME", "MDP", "BKSC", "RNC", "HTE", "TATA", "KQR", "CKP", "SINI", "GTS"].includes(c)) return "Jharkhand";
  if (["BPL", "HBJ", "RKMP", "ET", "JBP", "STA", "GWL", "UJN", "INDB", "KTE", "BINA"].includes(c)) return "Madhya Pradesh";
  if (["LDH", "ASR", "JUC", "PTK", "FZR", "BTI", "MSZ", "ABS", "GJS", "KKP"].includes(c)) return "Punjab";
  if (["MAS", "MS", "TBM", "CBE", "MDU", "TPJ", "ED", "SA"].includes(c)) return "Tamil Nadu";
  if (["SBC", "YPR", "MYS", "UBL", "SUR"].includes(c)) return "Karnataka";
  if (["SC", "HYB", "KZJ", "WL"].includes(c)) return "Telangana";
  if (["BZA", "VSKP", "RU", "TPTY"].includes(c)) return "Andhra Pradesh";
  if (["CTC", "BBS", "PURI", "BLS", "ROU", "GP", "BMB", "JSG", "BRJN"].includes(c)) return "Odisha";
  if (["BSP", "R", "DURG", "RIG", "KHS", "SKT", "CPH", "NIA", "AKT", "BYT", "TLD", "BIA"].includes(c)) return "Chhattisgarh";
  if (["GHY", "DBRG", "SCL"].includes(c)) return "Assam";
  if (["JAT", "SVDK"].includes(c)) return "Jammu & Kashmir";
  if (["DDN", "HW", "RK", "LKU"].includes(c)) return "Uttarakhand";
  if (["ERS", "TVC", "QLN", "CLT"].includes(c)) return "Kerala";

  if (n.includes("SAHARSA") || n.includes("PATNA") || n.includes("HAJIPUR") || n.includes("MUZAFFARPUR") || n.includes("SAMASTIPUR") || n.includes("DARBHANGA") || n.includes("BARAUNI") || n.includes("MOKAMA") || n.includes("GAYA") || n.includes("BIHAR")) return "Bihar";
  if (n.includes("DELHI") || n.includes("ANAND VIHAR") || n.includes("NIZAMUDDIN")) return "Delhi";
  if (n.includes("KANPUR") || n.includes("LUCKNOW") || n.includes("VARANASI") || n.includes("PRAYAGRAJ") || n.includes("GORAKHPUR") || n.includes("MUGHALSARAI") || n.includes("AGRA") || n.includes("GHAZIABAD") || n.includes("UP")) return "Uttar Pradesh";
  if (n.includes("KOLKATA") || n.includes("HOWRAH") || n.includes("SEALDAH") || n.includes("WEST BENGAL")) return "West Bengal";
  if (n.includes("JAIPUR") || n.includes("JODHPUR") || n.includes("AJMER") || n.includes("KOTA") || n.includes("RAJASTHAN")) return "Rajasthan";
  if (n.includes("SHIMLA") || n.includes("SOLAN") || n.includes("HIMACHAL")) return "Himachal Pradesh";
  if (n.includes("AHMEDABAD") || n.includes("VADODARA") || n.includes("SURAT") || n.includes("GUJARAT")) return "Gujarat";
  if (n.includes("MUMBAI") || n.includes("PUNE") || n.includes("MAHARASHTRA")) return "Maharashtra";
  if (n.includes("BHOPAL") || n.includes("INDORE") || n.includes("MADHYA PRADESH")) return "Madhya Pradesh";

  return "Bihar";
}

const getClassFare = (basePrice: number, className: string) => {
  const cleanName = className.trim().toUpperCase().split(" ")[0];
  let factor = 1.0;
  if (cleanName === "SL") factor = 0.4;
  else if (cleanName === "3A") factor = 0.8;
  else if (cleanName === "2A") factor = 1.2;
  else if (cleanName === "1A") factor = 2.0;
  else if (cleanName === "CC") factor = 0.7;
  else if (cleanName === "EC") factor = 1.4;
  return Math.round(basePrice * factor);
};

// ═══════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════

export default function TrainWisePage() {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [selectedClass, setSelectedClass] = useState("3A");
  const [mapType, setMapType] = useState<"google" | "vector">("vector");

  // Route Animation States
  const [animatingIdx, setAnimatingIdx] = useState<number | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);

  const startRouteAnimation = (routeList: any[], type: 'global' | 'local' = 'global') => {
    if (!routeList || routeList.length === 0) return;
    setIsAnimating(true);
    setAnimatingIdx(0);
    
    if ((window as any).routeAnimationInterval) {
      clearInterval((window as any).routeAnimationInterval);
    }
    
    let currentIdx = 0;
    const interval = setInterval(() => {
      if (currentIdx >= routeList.length - 1) {
        clearInterval(interval);
        setIsAnimating(false);
        setAnimatingIdx(null);
      } else {
        currentIdx++;
        setAnimatingIdx(currentIdx);
        const element = document.getElementById(`${type}-station-row-${currentIdx}`);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
    }, 1600);
    
    (window as any).routeAnimationInterval = interval;
  };

  const stopRouteAnimation = () => {
    if ((window as any).routeAnimationInterval) {
      clearInterval((window as any).routeAnimationInterval);
    }
    setIsAnimating(false);
    setAnimatingIdx(null);
  };

  // Train direct lookup state
  const [cockpitTrainNo, setCockpitTrainNo] = useState("");
  const [globalShowTimetableModal, setGlobalShowTimetableModal] = useState(false);
  const [globalScheduleData, setGlobalScheduleData] = useState<any>(null);
  const [globalLoadingSchedule, setGlobalLoadingSchedule] = useState(false);
  const [globalLookupError, setGlobalLookupError] = useState("");

  useEffect(() => {
    if (!globalShowTimetableModal) {
      stopRouteAnimation();
    }
  }, [globalShowTimetableModal]);

  // Map Explorer Route State
  const [mapExplorerTrain, setMapExplorerTrain] = useState<any>(null);
  const [loadingMapRoute, setLoadingMapRoute] = useState(false);

  const handleMapRouteLookup = async (trainNumber?: string) => {
    const searchNum = (trainNumber || cockpitTrainNo).trim();
    if (!searchNum) return;
    
    setLoadingMapRoute(true);
    setGlobalLookupError("");
    try {
      const res = await fetch("/api/schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trainNo: searchNum })
      });
      const json = await res.json();
      if (json && json.success && json.data) {
        setMapExplorerTrain({
          trainNo: json.data.trainNo,
          trainName: json.data.trainName,
          stops: json.data.route
        });
      } else {
        setGlobalLookupError(json.error || "Train not found.");
      }
    } catch (e) {
      setGlobalLookupError("Telemetry lookup failed.");
    } finally {
      setLoadingMapRoute(false);
    }
  };

  const [pnrNumber, setPnrNumber] = useState("");
  const [pnrLoading, setPnrLoading] = useState(false);
  const [pnrResult, setPnrResult] = useState<any>(null);
  const [pnrError, setPnrError] = useState("");
  const [showPnrModal, setShowPnrModal] = useState(false);

  const handleCheckPnr = async () => {
    if (!pnrNumber.trim() || pnrNumber.trim().length !== 10) {
      setPnrError("Please enter a valid 10-digit PNR.");
      return;
    }
    setPnrError("");
    setPnrLoading(true);
    setShowPnrModal(true);
    setPnrResult(null);
    try {
      const res = await fetch("/api/pnr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pnr: pnrNumber })
      });
      const json = await res.json();
      if (json && json.success && json.data) {
        setPnrResult(json.data);
      } else {
        setPnrError("PNR not found or invalid.");
      }
    } catch (err) {
      setPnrError("Failed to verify PNR status.");
    } finally {
      setPnrLoading(false);
    }
  };

  const handleDirectTrainLookup = async (trainNumber?: string) => {
    const searchNum = (trainNumber || cockpitTrainNo).trim();
    if (!searchNum) return;
    setGlobalLookupError("");
    setGlobalLoadingSchedule(true);
    setGlobalShowTimetableModal(true);
    setGlobalScheduleData(null);
    try {
      const res = await fetch("/api/schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trainNo: searchNum })
      });
      const json = await res.json();
      if (json && json.success && json.data) {
        setGlobalScheduleData(json.data);
      } else {
        setGlobalLookupError("Train schedule not found. Please verify the train number.");
      }
    } catch (err) {
      console.error("Failed to load train schedule", err);
      setGlobalLookupError("Failed to fetch schedule data. Please check your internet connection.");
    } finally {
      setGlobalLoadingSchedule(false);
    }
  };

  // Search state
  const originRef = useRef<HTMLDivElement>(null);
  const destRef = useRef<HTMLDivElement>(null);

  const [originCode, setOriginCode] = useState("PNBE");
  const [originName, setOriginName] = useState("PATNA JN");
  const [destCode, setDestCode] = useState("SML");
  const [destName, setDestName] = useState("SHIMLA");

  const [originQuery, setOriginQuery] = useState("");
  const [destQuery, setDestQuery] = useState("");
  const [showOriginDrop, setShowOriginDrop] = useState(false);
  const [showDestDrop, setShowDestDrop] = useState(false);

  // Route state
  const [routes, setRoutes] = useState<TrainRoute[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [hasSearched, setHasSearched] = useState(false);

  // Loading/API state
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [searchDate, setSearchDate] = useState("2026-07-15");
  const [aiRec, setAiRec] = useState("");

  // Advanced Filter States
  const [maxBudget, setMaxBudget] = useState(8000);
  const [selectedCoaches, setSelectedCoaches] = useState<string[]>(["SL", "3A", "2A", "1A", "CC", "EC"]);
  const [selectedSlots, setSelectedSlots] = useState<string[]>([]);
  const [selectedTrainTypes, setSelectedTrainTypes] = useState<string[]>(["Vande Bharat", "Rajdhani", "Shatabdi", "Duronto", "Express"]);
  const [maxTransfers, setMaxTransfers] = useState(2);
  const [maxLayover, setMaxLayover] = useState(8);
  const [confirmedOnly, setConfirmedOnly] = useState(false);
  const [activeTab, setActiveTab] = useState<"ai" | "split" | "direct" | "cheapest" | "premium">("ai");
  const [sortBy, setSortBy] = useState<"money" | "time">("money");
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(true);

  // Authentication & Session state
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authTab, setAuthTab] = useState<"signin" | "signup">("signin");
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  
  // Auth Form Input states
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [authError, setAuthError] = useState("");
  const [authIsLoading, setAuthIsLoading] = useState(false);

  // User Modals
  const [showBookingsModal, setShowBookingsModal] = useState(false);
  const [showTelemetryModal, setShowTelemetryModal] = useState(false);

  // Close profile dropdown when clicking outside
  const profileRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setShowProfileDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    if (!authEmail || !authPassword) {
      setAuthError("All fields are required.");
      return;
    }
    setAuthIsLoading(true);
    setTimeout(() => {
      const derivedName = authEmail.split("@")[0].split(".")[0];
      const capitalizedName = derivedName.charAt(0).toUpperCase() + derivedName.slice(1);
      setUser({
        name: capitalizedName || "Garv Tandon",
        email: authEmail,
      });
      setAuthIsLoading(false);
      setShowAuthModal(false);
      setAuthEmail("");
      setAuthPassword("");
    }, 800);
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    if (!authEmail || !authPassword || !authName) {
      setAuthError("All fields are required.");
      return;
    }
    setAuthIsLoading(true);
    setTimeout(() => {
      setUser({
        name: authName,
        email: authEmail,
      });
      setAuthIsLoading(false);
      setShowAuthModal(false);
      setAuthEmail("");
      setAuthPassword("");
      setAuthName("");
    }, 800);
  };

  const handleOAuthLogin = (provider: "google" | "passkey") => {
    setAuthIsLoading(true);
    setAuthError("");
    setTimeout(() => {
      setUser({
        name: "Garv Tandon",
        email: provider === "google" ? "garv.tandon@gmail.com" : "garv@passkey.io",
      });
      setAuthIsLoading(false);
      setShowAuthModal(false);
    }, 600);
  };

  const handleSignOut = () => {
    setUser(null);
    setShowProfileDropdown(false);
  };

  // Autocomplete filtering
  const filteredOrigin = useMemo(() => {
    if (!originQuery.trim()) return allStations.slice(0, 20);
    const q = originQuery.toLowerCase().trim();

    const MAJOR_STATIONS: Record<string, number> = {
      "PNBE": 2500, "PPTA": 1800, "PNC": 1400, "NDLS": 3000, "HWH": 2200,
      "CSMT": 2200, "JP": 2000, "ADI": 1800, "CNB": 1800, "DDU": 2000,
      "LKO": 1800, "GKP": 1600, "HJP": 1600, "MFP": 1500, "DBG": 1500,
      "BJU": 1400, "BSB": 1600, "SBC": 2000, "YPR": 1600, "MAS": 2000,
      "GHY": 1800, "SC": 1900, "BDTS": 1800, "MMCT": 1800, "CDG": 1600,
      "LDH": 1400, "ASR": 1500, "JAT": 1600, "KYN": 1500, "PUNE": 1900
    };

    const scored: { station: RawStation; score: number }[] = [];

    for (const st of allStations) {
      const codeLower = st.code.toLowerCase();
      const nameLower = st.name.toLowerCase();
      
      let score = 0;
      
      if (codeLower === q) {
        score += 10000;
      } else if (nameLower === q) {
        score += 9000;
      } else if (codeLower.startsWith(q)) {
        score += 6000 + (5 - codeLower.length);
      } else if (nameLower.startsWith(q)) {
        score += 5000;
      } else if (nameLower.includes(" " + q)) {
        score += 3000;
      } else if (nameLower.includes(q)) {
        score += 1000;
      } else if (codeLower.includes(q)) {
        score += 800;
      }

      const aliasCode = STATION_ALIASES[q];
      if (aliasCode && st.code.toUpperCase() === aliasCode.toUpperCase()) {
        score += 15000;
      }

      for (const [stateName, codes] of Object.entries(STATE_STATIONS)) {
        if (stateName === q || (q === 'up' && stateName === 'up') || (stateName.startsWith(q) && q.length >= 3)) {
          if (codes.includes(st.code.toUpperCase())) {
            score += 8000;
          }
        }
      }

      if (score > 0) {
        if (MAJOR_STATIONS[st.code]) {
          score += MAJOR_STATIONS[st.code];
        }
        scored.push({ station: st, score });
      }
    }

    scored.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return a.station.name.localeCompare(b.station.name);
    });

    return scored.map(s => s.station).slice(0, 20);
  }, [originQuery]);

  const filteredDest = useMemo(() => {
    if (!destQuery.trim()) return allStations.slice(0, 20);
    const q = destQuery.toLowerCase().trim();

    const MAJOR_STATIONS: Record<string, number> = {
      "PNBE": 2500, "PPTA": 1800, "PNC": 1400, "NDLS": 3000, "HWH": 2200,
      "CSMT": 2200, "JP": 2000, "ADI": 1800, "CNB": 1800, "DDU": 2000,
      "LKO": 1800, "GKP": 1600, "HJP": 1600, "MFP": 1500, "DBG": 1500,
      "BJU": 1400, "BSB": 1600, "SBC": 2000, "YPR": 1600, "MAS": 2000,
      "GHY": 1800, "SC": 1900, "BDTS": 1800, "MMCT": 1800, "CDG": 1600,
      "LDH": 1400, "ASR": 1500, "JAT": 1600, "KYN": 1500, "PUNE": 1900
    };

    const scored: { station: RawStation; score: number }[] = [];

    for (const st of allStations) {
      const codeLower = st.code.toLowerCase();
      const nameLower = st.name.toLowerCase();
      
      let score = 0;
      
      if (codeLower === q) {
        score += 10000;
      } else if (nameLower === q) {
        score += 9000;
      } else if (codeLower.startsWith(q)) {
        score += 6000 + (5 - codeLower.length);
      } else if (nameLower.startsWith(q)) {
        score += 5000;
      } else if (nameLower.includes(" " + q)) {
        score += 3000;
      } else if (nameLower.includes(q)) {
        score += 1000;
      } else if (codeLower.includes(q)) {
        score += 800;
      }

      const aliasCode = STATION_ALIASES[q];
      if (aliasCode && st.code.toUpperCase() === aliasCode.toUpperCase()) {
        score += 15000;
      }

      for (const [stateName, codes] of Object.entries(STATE_STATIONS)) {
        if (stateName === q || (q === 'up' && stateName === 'up') || (stateName.startsWith(q) && q.length >= 3)) {
          if (codes.includes(st.code.toUpperCase())) {
            score += 8000;
          }
        }
      }

      if (score > 0) {
        if (MAJOR_STATIONS[st.code]) {
          score += MAJOR_STATIONS[st.code];
        }
        scored.push({ station: st, score });
      }
    }

    scored.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return a.station.name.localeCompare(b.station.name);
    });

    return scored.map(s => s.station).slice(0, 20);
  }, [destQuery]);

  // Click outside listener for dropdowns
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (originRef.current && !originRef.current.contains(event.target as Node)) {
        setShowOriginDrop(false);
      }
      if (destRef.current && !destRef.current.contains(event.target as Node)) {
        setShowDestDrop(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Auto-search and cockpit hydration on mount
  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const fromParam = params.get("from");
      const toParam = params.get("to");
      const dateParam = params.get("date");
      const budgetParam = params.get("budget");
      const coachesParam = params.get("coaches");
      const sortParam = params.get("sort");
      const signinParam = params.get("signin");
      const userParam = params.get("user");
      const emailParam = params.get("email");

      if (userParam && emailParam) {
        setUser({ name: userParam, email: emailParam });
      }

      if (signinParam === "true") {
        setShowAuthModal(true);
        setAuthTab("signin");
      }

      let finalOriginCode = originCode;
      let finalDestCode = destCode;
      let finalDate = searchDate;

      if (fromParam) {
        const c = fromParam.toUpperCase().trim();
        finalOriginCode = c;
        setOriginCode(c);
        const st = allStations.find(s => s.code.toUpperCase() === c);
        if (st) setOriginName(st.name);
      }
      if (toParam) {
        const c = toParam.toUpperCase().trim();
        finalDestCode = c;
        setDestCode(c);
        const st = allStations.find(s => s.code.toUpperCase() === c);
        if (st) setDestName(st.name);
      }
      if (dateParam) {
        finalDate = dateParam;
        setSearchDate(dateParam);
      }
      if (budgetParam) {
        const bVal = parseInt(budgetParam, 10);
        if (!isNaN(bVal)) setMaxBudget(bVal);
      }
      if (coachesParam) {
        const coachArr = coachesParam.split(",").map(c => c.trim().toUpperCase());
        if (coachArr.length > 0) setSelectedCoaches(coachArr);
      }
      if (sortParam) {
        const s = sortParam.toLowerCase();
        if (["ai", "split", "direct", "cheapest", "premium"].includes(s)) {
          setActiveTab(s as any);
        }
      }

      const hasFromTo = !!fromParam && !!toParam;
      handleSearch(finalOriginCode, finalDestCode, finalDate, hasFromTo);
    } else {
      handleSearch(originCode, destCode, searchDate, false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSearch(orig = originCode, dest = destCode, dte = searchDate, autoSelect = true) {
    let finalOrig = orig;
    let finalDest = dest;

    if (originQuery.trim()) {
      const topOrigin = filteredOrigin[0];
      if (topOrigin) {
        finalOrig = topOrigin.code;
        setOriginCode(topOrigin.code);
        setOriginName(topOrigin.name);
      }
    }

    if (destQuery.trim()) {
      const topDest = filteredDest[0];
      if (topDest) {
        finalDest = topDest.code;
        setDestCode(topDest.code);
        setDestName(topDest.name);
      }
    }

    setOriginQuery("");
    setDestQuery("");
    setShowOriginDrop(false);
    setShowDestDrop(false);

    setIsLoading(true);
    setErrorMsg("");
    setHasSearched(true);
    setAiRec("");
    try {
      // 1. Fetch Direct
      const directRes = await fetch("/api/search-direct", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source: finalOrig,
          destination: finalDest,
          date: dte,
          classType: "Any"
        })
      });
      const directData = await directRes.json();
      if (directData.error) throw new Error(directData.error);
      const directList = directData.directTrains || [];

      // 2. Fetch Split
      const splitRes = await fetch("/api/search-split", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source: finalOrig,
          destination: finalDest,
          date: dte,
          classType: "Any",
          directTrains: directList
        })
      });
      const splitData = await splitRes.json();
      const splitList = splitData.splitRoutes || [];
      const recommendation = splitData.aiRecommendation || "";
      setAiRec(recommendation);

      // 3. Map Direct
      const mappedDirect = directList.map((t: any, idx: number) => ({
        id: `d-${t.trainNo}-${idx}`,
        name: t.trainName,
        type: "direct" as const,
        preview: [t.source, t.destination],
        totalDuration: t.duration,
        transfers: 0,
        price: parseFloat(t.fare.replace('₹', '')) || 999,
        classes: t.classes || ["3A", "2A", "1A"],
        isRecommended: t.trainType === "Vande Bharat" || t.trainType === "Rajdhani" || idx === 0,
        tag: t.trainType === "Vande Bharat" ? "FASTEST • VANDE BHARAT" : t.trainType === "Rajdhani" ? "PREMIUM RAJDHANI" : "DIRECT TRIP",
        stationCodes: [t.source, t.destination],
        legs: [
          {
            type: "train" as const,
            name: t.trainName,
            number: t.trainNo,
            from: `${t.source}`,
            to: `${t.destination}`,
            depTime: t.departureTime,
            arrTime: t.arrivalTime,
            platform: t.platform || "Pf #1",
            duration: t.duration,
            classType: t.classType || "3A",
            price: parseFloat(t.fare.replace('₹', '')) || 999,
          }
        ],
        rating: t.rating || 4.5,
        features: t.features || ["Charging Port", "Catering Available"],
        cleanlinessScore: t.cleanlinessScore || 92,
        punctualityScore: t.punctualityScore || 94,
        availability: t.availability || "AVAILABLE - 0042",
        confirmationChance: t.confirmationChance || "High",
      }));

      // 4. Map Split
      const mappedSplit = splitList.map((r: any, idx: number) => {
        if (r.legs && r.legs.length > 0) {
          return {
            id: r.id || `s-${idx}-${Date.now()}`,
            name: r.name || "Multi-Segment Journey",
            type: "split" as const,
            preview: r.preview || [r.legs[0].from, r.legs[r.legs.length - 1].to],
            totalDuration: r.totalDuration || "15h 30m",
            transfers: r.transfers || Math.floor(r.legs.length / 2),
            price: typeof r.price === 'number' ? r.price : parseFloat(String(r.price || r.totalFare || '').replace('₹', '')) || 1650,
            classes: r.classes || ["3A", "2A", "1A"],
            isRecommended: r.isRecommended !== undefined ? r.isRecommended : idx === 0,
            tag: r.tag || `MULTI-TRANSIT ROUTE`,
            stationCodes: r.stationCodes || [r.legs[0].from, r.legs[r.legs.length - 1].to],
            legs: r.legs,
            rating: r.rating || 4.6,
            features: r.features || ["Direct Platform Sync", "Luggage Assistance", "Catering Verified"],
            cleanlinessScore: r.cleanlinessScore || 94,
            punctualityScore: r.punctualityScore || 95,
            availability: r.availability || "AVAILABLE",
            confirmationChance: r.confirmationChance || r.combinedConfirmationChance || 98,
          };
        }

        const t1 = r.leg1;
        const t2 = r.leg2;
        return {
          id: `s-${t1.trainNo}-${t2.trainNo}-${idx}`,
          name: `${t1.trainName.split(" ")[0]} ➜ ${t2.trainName.split(" ")[0]}`,
          type: "split" as const,
          preview: [t1.source, r.hubStation, t2.destination],
          totalDuration: `${t1.duration} + ${t2.duration}`,
          transfers: 1,
          price: typeof r.totalFare === 'number' ? r.totalFare : parseFloat(String(r.totalFare || '').replace('₹', '')) || 1450,
          classes: Array.from(new Set([...(t1.classes || []), ...(t2.classes || [])])),
          isRecommended: idx === 0,
          tag: `SMART SPLIT via ${r.hubStationName || r.hubStation}`,
          stationCodes: [t1.source, r.hubStation, t2.destination],
          legs: [
            {
              type: "train" as const,
              name: t1.trainName,
              number: t1.trainNo,
              from: `${t1.source}`,
              to: `${r.hubStation}`,
              depTime: t1.departureTime,
              arrTime: t1.arrivalTime,
              platform: t1.platform || "Pf #2",
              duration: t1.duration,
              classType: t1.classType || "3A",
              price: parseFloat(t1.fare.replace('₹', '')) || 999,
            },
            {
              type: "transfer" as const,
              from: `${r.hubStation}`,
              to: `${r.hubStation}`,
              duration: r.layoverDuration,
              transferDetails: `De-board at Platform ${t1.platform || '2'} and transition to Platform ${t2.platform || '1'} (${r.layoverDuration} wait).`
            },
            {
              type: "train" as const,
              name: t2.trainName,
              number: t2.trainNo,
              from: `${r.hubStation}`,
              to: `${t2.destination}`,
              depTime: t2.departureTime,
              arrTime: t2.arrivalTime,
              platform: t2.platform || "Pf #1",
              duration: t2.duration,
              classType: t2.classType || "3A",
              price: parseFloat(t2.fare.replace('₹', '')) || 450,
            }
          ],
          rating: Math.round(((t1.rating || 4.2) + (t2.rating || 4.2)) / 2 * 10) / 10,
          features: Array.from(new Set([...(t1.features || []), ...(t2.features || [])])),
          cleanlinessScore: t1.cleanlinessScore,
          punctualityScore: t1.punctualityScore,
          availability: `Leg 1: ${t1.availability} • Leg 2: ${t2.availability}`,
          confirmationChance: r.combinedConfirmationChance,
        };
      });

      const combined: TrainRoute[] = [...mappedDirect, ...mappedSplit];
      setRoutes(combined);
      setSelectedId(autoSelect ? (combined[0]?.id || "") : "");
    } catch (err: any) {
      console.error(err);
      setErrorMsg("Failed to connect to IRCTC Proxy Server. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }

  function handleSwap() {
    const oc = originCode, on = originName;
    setOriginCode(destCode); setOriginName(destName);
    setDestCode(oc); setDestName(on);
  }

  // Filters logic
  const filteredAndSortedRoutes = useMemo(() => {
    let list = [...routes];

    if (activeTab === "split") {
      list = list.filter(r => r.type === "split");
    } else if (activeTab === "direct") {
      list = list.filter(r => r.type === "direct");
    }

    list = list.filter(r => {
      if (r.price > maxBudget) return false;
      if (r.transfers > maxTransfers) return false;
      
      const hasClass = r.classes.some(c => selectedCoaches.includes(c));
      if (!hasClass && selectedCoaches.length > 0) return false;

      if (confirmedOnly) {
        const cChance = (r as any).confirmationChance;
        if (cChance !== undefined) {
          const val = typeof cChance === 'number' ? cChance : parseInt(String(cChance).replace('%', ''));
          if (!isNaN(val) && val < 75) return false;
        }
      }

      if (r.type === "split") {
        const layoverLegs = r.legs.filter(l => l.type === "transfer");
        for (const leg of layoverLegs) {
          const hrsMatch = leg.duration.match(/(\d+)\s*h/);
          const minsMatch = leg.duration.match(/(\d+)\s*m/);
          const hrs = hrsMatch ? parseInt(hrsMatch[1]) : 0;
          const mins = minsMatch ? parseInt(minsMatch[1]) : 0;
          const totalHrs = hrs + mins / 60;
          if (totalHrs > maxLayover) return false;
        }
      }

      const firstLeg = r.legs[0];
      if (firstLeg && firstLeg.depTime && selectedSlots.length > 0) {
        const [hStr] = firstLeg.depTime.split(":");
        const h = parseInt(hStr);
        let slot = "Night";
        if (h >= 6 && h < 12) slot = "Morning";
        else if (h >= 12 && h < 18) slot = "Afternoon";
        else if (h >= 18 && h <= 23) slot = "Evening";
        if (!selectedSlots.includes(slot)) return false;
      }

      if (selectedTrainTypes.length > 0) {
        const matchesType = r.legs.some(l => {
          if (l.type === "train" && l.name) {
            const name = l.name.toLowerCase();
            if (selectedTrainTypes.includes("Vande Bharat") && name.includes("vande bharat")) return true;
            if (selectedTrainTypes.includes("Rajdhani") && name.includes("rajdhani")) return true;
            if (selectedTrainTypes.includes("Shatabdi") && name.includes("shatabdi")) return true;
            if (selectedTrainTypes.includes("Express") && (name.includes("express") || name.includes("duronto") || name.includes("poorva") || name.includes("superfast"))) return true;
          }
          return false;
        });
        if (!matchesType) return false;
      }

      return true;
    });

    if (sortBy === "time") {
      list.sort((a, b) => getRouteTotalDurationMinutes(a) - getRouteTotalDurationMinutes(b));
    } else {
      if (activeTab === "cheapest") {
        list.sort((a, b) => a.price - b.price);
      } else if (activeTab === "premium") {
        const isPremium = (r: TrainRoute) => r.legs.some(l => l.name?.toLowerCase().includes("vande bharat") || l.name?.toLowerCase().includes("rajdhani") || l.name?.toLowerCase().includes("shatabdi"));
        list.sort((a, b) => {
          if (isPremium(a) && !isPremium(b)) return -1;
          if (!isPremium(a) && isPremium(b)) return 1;
          return b.price - a.price;
        });
      } else if (activeTab === "ai") {
        list.sort((a, b) => {
          if (a.isRecommended && !b.isRecommended) return -1;
          if (!a.isRecommended && b.isRecommended) return 1;
          return a.price - b.price;
        });
      } else {
        list.sort((a, b) => a.price - b.price);
      }
    }

    return list;
  }, [routes, activeTab, maxBudget, selectedCoaches, selectedSlots, selectedTrainTypes, maxTransfers, maxLayover, confirmedOnly, sortBy]);

  const selectedRoute = selectedId ? (filteredAndSortedRoutes.find(r => r.id === selectedId) || filteredAndSortedRoutes[0]) : undefined;

  // Sync selectedClass to route classes
  useEffect(() => {
    if (selectedRoute) {
      const routeClasses = selectedRoute.classes || ["3A"];
      if (!routeClasses.includes(selectedClass)) {
        setSelectedClass(routeClasses[0] || "3A");
      }
    }
  }, [selectedRoute, selectedClass]);

  const currentFare = selectedRoute ? getClassFare(selectedRoute.price, selectedClass) : 0;

  const comfortScore = useMemo(() => {
    if (!selectedRoute) return 90;
    let score = 98;
    if (selectedRoute.transfers === 1) score -= 12;
    if (selectedRoute.transfers > 1) score -= 20;

    selectedRoute.legs.forEach(l => {
      if (l.type === "transfer") {
        const hrs = parseInt(l.duration) || 1;
        if (hrs > 4) score -= 8;
        if (hrs < 1) score -= 5;
      }
    });

    const nameStr = selectedRoute.name.toLowerCase();
    if (nameStr.includes("vande bharat")) score += 4;
    if (nameStr.includes("rajdhani")) score += 3;
    if (nameStr.includes("shatabdi")) score += 2;

    return Math.min(100, Math.max(40, score));
  }, [selectedRoute]);

  const activeSelectedRoute = useMemo(() => {
    if (mapExplorerTrain) {
      return {
        id: mapExplorerTrain.trainNo,
        name: `${mapExplorerTrain.trainNo} - ${mapExplorerTrain.trainName}`,
        type: 'direct' as const,
        price: 0,
        totalDuration: '',
        transfers: 0,
        classes: [],
        stationCodes: mapExplorerTrain.stops.map((s: any) => s.stnCode),
        legs: [
          {
            type: 'train' as const,
            name: mapExplorerTrain.trainName,
            number: mapExplorerTrain.trainNo,
            from: mapExplorerTrain.stops[0]?.stnCode || '',
            to: mapExplorerTrain.stops[mapExplorerTrain.stops.length - 1]?.stnCode || '',
            depTime: '',
            arrTime: '',
            duration: '',
            classType: '',
            price: 0
          }
        ],
        preview: mapExplorerTrain.stops.map((s: any) => s.stnCode)
      };
    }
    return selectedRoute;
  }, [selectedRoute, mapExplorerTrain]);

  const mapStops = useMemo(() => {
    if (activeSelectedRoute) {
      return buildRouteCoords(activeSelectedRoute.stationCodes);
    }
    return [];
  }, [activeSelectedRoute]);

  const handleBookSegment = (stopFrom: string, stopTo: string, stnFromCode: string, stnToCode: string) => {
    const textToCopy = `TRAINWISE BOOKING CREDENTIALS\nFrom: ${stopFrom} (${stnFromCode})\nTo: ${stopTo} (${stnToCode})\nClass: ${selectedClass}\nDate: ${searchDate}`;
    navigator.clipboard.writeText(textToCopy);
    window.open("https://www.irctc.co.in/nget/train-search", "_blank");
  };

  // Theme variable maps
  const d = isDarkMode;
  
  // Custom Color Accents & Shadows
  const bg = d ? "bg-[#090B11] text-slate-100" : "bg-[#F8FAFD] text-slate-800";
  const headerBg = d ? "bg-[#0B0F19]/80 border-white/5 shadow-2xl" : "bg-white/90 border-slate-200 shadow-sm";
  const textMuted = d ? "text-slate-500" : "text-slate-400";
  const textSec = d ? "text-slate-400" : "text-slate-500";
  const pillBg = d ? "bg-slate-900/60 border-white/5" : "bg-slate-100 border-slate-200";
  const inputBg = d ? "bg-slate-950/80 border-white/5" : "bg-white border-slate-200";
  const dropBg = d ? "bg-[#0B0F19] border-white/10 shadow-[0_12px_40px_rgba(0,0,0,0.8)] text-slate-200" : "bg-white border-slate-200 shadow-[0_12px_40px_rgba(0,0,0,0.1)] text-slate-800";
  const cardBase = d ? "bg-[#111625]/60 border-white/5 hover:border-orange-500/30" : "bg-white border-slate-200/80 hover:border-orange-400 shadow-[0_4px_20px_rgba(0,0,0,0.02)]";
  const panelBg = d ? "bg-[#0C101F]/80 border-white/5 shadow-[0_20px_50px_rgba(0,0,0,0.5)]" : "bg-white/90 border-slate-250/70 shadow-[0_15px_35px_rgba(0,0,0,0.04)]";
  const dividerColor = d ? "border-white/5" : "border-slate-200/60";

  return (
    <div className={`min-h-screen font-sans antialiased overflow-x-hidden relative transition-colors duration-500 ${bg}`}>
      {/* Background vector decorations */}
      <div className="absolute inset-0 bg-[size:24px_24px] pointer-events-none opacity-20 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)]" />

      {/* ═══ TOP NAVBAR ═══ */}
      <header className={`sticky top-0 z-50 backdrop-blur-xl border-b transition-all duration-500 px-6 py-3 flex items-center justify-between ${headerBg}`}>
        <div className="flex items-center gap-3">
          <Link href="/" className={`flex items-center gap-1 text-xs font-black mr-2 tracking-wide font-mono uppercase ${textSec} ${d ? "hover:text-slate-200" : "hover:text-slate-900"}`}>
            <ArrowLeft className="w-4 h-4 text-orange-500 shrink-0" />
            <span>Home</span>
          </Link>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-orange-500 to-red-650 flex items-center justify-center shadow-[0_0_16px_rgba(239,68,68,0.2)]">
            <Compass className="w-5 h-5 text-white animate-spin-slow" />
          </div>
          <div>
            <h1 className="text-base font-black tracking-tight flex items-center gap-1.5 uppercase font-mono">
              <span className={d ? "text-white" : "text-slate-900"}>Train</span>
              <span className="bg-gradient-to-r from-orange-500 to-red-600 bg-clip-text text-transparent drop-shadow-[0_0_8px_rgba(249,115,22,0.4)]">Wise</span>
            </h1>
            <p className={`text-[7.5px] font-mono tracking-widest ${textMuted}`}>NEXT-GEN BOOKING PILOT</p>
          </div>
        </div>

        {/* Dynamic Navigation Links */}
        <div className="hidden lg:flex items-center gap-1 bg-slate-500/5 px-2 py-1 rounded-full border border-slate-500/10 shadow-inner">
          {["Find Trains", "PNR Status", "About"].map((label) => (
            <button
              key={label}
              onClick={() => handleSearch()}
              className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider transition-all duration-300 font-mono ${
                d ? "text-slate-400 hover:text-white" : "text-slate-500 hover:text-slate-900"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          {/* Dedicated check PNR button */}
          <button
            onClick={() => { setPnrError(""); setShowPnrModal(true); }}
            className={`px-3 py-1.5 rounded-xl border text-[10px] font-black tracking-wider uppercase font-mono transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 ${
              d
                ? "bg-orange-500/10 border-orange-500/20 text-orange-400 hover:bg-orange-500/20 shadow-[0_0_12px_rgba(249,115,22,0.1)]"
                : "bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100 shadow-sm"
            }`}
          >
            <Train className="w-3.5 h-3.5" />
            <span>Check PNR</span>
          </button>

          {/* User Sign In and profile dropdown */}
          {user ? (
            <div className="relative" ref={profileRef}>
              <button
                onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                className={`relative w-9 h-9 rounded-xl flex items-center justify-center font-black text-xs cursor-pointer border transition-all ${
                  d
                    ? "bg-slate-950 border-white/10 text-orange-400 hover:bg-slate-900"
                    : "bg-slate-100 border-slate-300 text-orange-650 hover:bg-slate-200 shadow-sm"
                }`}
              >
                <span className="absolute -inset-0.5 rounded-xl bg-orange-500/20 animate-ping opacity-60 pointer-events-none" />
                {user.name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2)}
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-slate-950" />
              </button>

              <AnimatePresence>
                {showProfileDropdown && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className={`absolute right-0 mt-2.5 w-56 rounded-2xl backdrop-blur-md border p-3.5 flex flex-col gap-2.5 z-50 shadow-2xl select-none ${
                      d
                        ? "bg-[#0B0F19]/95 border-white/10 text-slate-350"
                        : "bg-white/95 border-slate-200 text-slate-700"
                    }`}
                  >
                    <div className="px-2 py-1.5 border-b border-slate-500/10 flex flex-col">
                      <span className={`text-[7.5px] font-black uppercase tracking-widest ${d ? "text-orange-400" : "text-orange-600"}`}>TRAINWISE USER</span>
                      <span className={`text-xs font-black truncate ${d ? "text-slate-100" : "text-slate-950"}`}>{user.name}</span>
                      <span className={`text-[9px] opacity-60 truncate font-mono mt-0.5`}>{user.email}</span>
                    </div>

                    <button
                      onClick={() => { setShowBookingsModal(true); setShowProfileDropdown(false); }}
                      className={`w-full text-left px-2 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                        d ? "hover:bg-white/5 text-slate-300" : "hover:bg-slate-50 text-slate-700"
                      }`}
                    >
                      <Calendar className="w-4 h-4 opacity-80" />
                      View Bookings
                    </button>

                    <button
                      onClick={() => { setShowTelemetryModal(true); setShowProfileDropdown(false); }}
                      className={`w-full text-left px-2 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                        d ? "hover:bg-white/5 text-orange-400" : "hover:bg-slate-50 text-orange-650 font-bold"
                      }`}
                    >
                      <Activity className="w-4 h-4" />
                      Telemetry Console
                    </button>

                    <div className="h-[1px] bg-slate-500/10 my-1" />

                    <button
                      onClick={handleSignOut}
                      className="w-full text-left px-2 py-2 rounded-xl text-xs font-black uppercase tracking-wider font-mono flex items-center gap-2 cursor-pointer text-red-400 hover:bg-red-500/10 transition-all"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <button
              onClick={() => { setAuthTab("signin"); setShowAuthModal(true); }}
              className={`px-4 py-2 rounded-xl border text-[10px] font-black uppercase tracking-wider font-mono transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 ${
                d
                  ? "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
                  : "bg-slate-100 border-slate-300/80 text-slate-700 hover:bg-slate-200"
              }`}
            >
              <User className="w-3.5 h-3.5" />
              Sign In
            </button>
          )}

          {/* Theme Toggle */}
          <button onClick={() => setIsDarkMode(!isDarkMode)} aria-label="Toggle theme"
            className={`relative w-14 h-8 rounded-full p-1 cursor-pointer overflow-hidden transition-all duration-500 ${
              d ? "bg-[#111625] border border-white/10" : "bg-slate-200 border border-slate-350 shadow-inner"
            }`}>
            <motion.div layout transition={{ type: "spring", stiffness: 500, damping: 30 }}
              className={`relative w-6 h-6 rounded-full flex items-center justify-center shadow-md z-10 ${
                d ? "bg-gradient-to-tr from-orange-500 to-red-600 ml-auto" : "bg-gradient-to-tr from-amber-400 to-yellow-500 ml-0"
              }`}>
              {d ? <Moon className="w-3.5 h-3.5 text-white" /> : <Sun className="w-3.5 h-3.5 text-white" />}
            </motion.div>
          </button>
        </div>
      </header>

      {/* ═══ PREMIUM SEARCH HEADER ═══ */}
      <section className={`px-6 py-4 border-b ${dividerColor} flex flex-col items-center justify-center`}>
        <div className={`flex flex-wrap lg:flex-nowrap items-center border rounded-3xl p-1.5 gap-1.5 relative transition-all duration-500 max-w-6xl w-full ${
          d ? "bg-slate-950/60 border-white/5" : "bg-white border-slate-200 shadow-sm"
        }`}>
          
          {/* FROM Station selector */}
          <div ref={originRef} className="relative flex-1 min-w-[200px]">
            <button onClick={() => { setShowOriginDrop(!showOriginDrop); setShowDestDrop(false); setOriginQuery(""); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl cursor-pointer ${
                d ? "hover:bg-white/5" : "hover:bg-slate-100"
              }`}>
              <MapPin className="w-4 h-4 text-orange-500 shrink-0" />
              <div className="text-left min-w-0">
                <p className={`text-[7px] uppercase font-black font-mono tracking-widest ${textMuted}`}>FROM STATION</p>
                <p className={`font-black text-xs truncate max-w-[170px] ${d ? "text-slate-100" : "text-slate-800"}`}>{originName} ({originCode})</p>
              </div>
              <ChevronDown className={`w-3.5 h-3.5 ${textMuted} ml-auto shrink-0`} />
            </button>

            <AnimatePresence>
              {showOriginDrop && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
                  className={`absolute left-0 top-full mt-2.5 w-80 backdrop-blur-2xl border rounded-2xl p-3 z-[60] space-y-2 ${dropBg}`}>
                  <p className={`text-[7.5px] font-black uppercase tracking-widest font-mono px-1 ${textMuted}`}>SELECT ORIGIN RAILWAY TERMINAL</p>
                  <div className={`relative flex items-center border rounded-xl px-1 py-1 ${inputBg}`}>
                    <Search className={`w-3.5 h-3.5 absolute left-3 ${textMuted}`} />
                    <input type="text" autoFocus placeholder="Station name, code, state..." value={originQuery} onChange={e => setOriginQuery(e.target.value)}
                      onClick={e => e.stopPropagation()}
                      className={`w-full pl-8 pr-2 py-1 bg-transparent text-xs font-bold outline-none ${
                        d ? "text-slate-200 placeholder:text-slate-500" : "text-slate-850 placeholder:text-slate-400"
                      }`} />
                  </div>
                  <div className="max-h-56 overflow-y-auto space-y-0.5 scrollbar-thin">
                    {filteredOrigin.map(st => (
                      <button key={st.code} disabled={st.code === destCode}
                        onClick={() => { setOriginCode(st.code); setOriginName(st.name); setOriginQuery(""); setShowOriginDrop(false); }}
                        className={`w-full text-left px-2.5 py-2.5 rounded-xl text-xs flex items-center justify-between transition-all ${
                          originCode === st.code ? d ? "bg-orange-500/20 text-white border border-orange-500/30" : "bg-orange-50 text-orange-700 border border-orange-200 font-bold"
                          : d ? "text-slate-300 hover:bg-white/5 border border-transparent" : "text-slate-650 hover:bg-slate-50 border border-transparent"
                        } ${st.code === destCode ? "opacity-30 cursor-not-allowed" : "cursor-pointer"}`}>
                        <div className="truncate">
                          <span className="font-black">{st.name}</span>
                          <span className={`ml-1.5 text-[8.5px] font-extrabold uppercase ${d ? "text-indigo-400" : "text-indigo-600"}`}>
                            ({getStateForStation(st.code, st.name)})
                          </span>
                        </div>
                        <span className={`text-[10px] font-mono shrink-0 font-bold ${textMuted}`}>{st.code}</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Animated 3D Swap button */}
          <button onClick={handleSwap} className={`w-8 h-8 rounded-xl border shrink-0 flex items-center justify-center cursor-pointer transition-all hover:scale-105 active:rotate-180 ${
            d ? "bg-white/5 border-white/5 text-slate-400 hover:bg-white/10" : "bg-white border-slate-200 text-slate-650 hover:bg-slate-100 shadow-sm"
          }`}>
            <ArrowLeftRight className="w-3.5 h-3.5 text-orange-500" />
          </button>

          {/* TO Station selector */}
          <div ref={destRef} className="relative flex-1 min-w-[200px]">
            <button onClick={() => { setShowDestDrop(!showDestDrop); setShowOriginDrop(false); setDestQuery(""); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl cursor-pointer ${
                d ? "hover:bg-white/5" : "hover:bg-slate-100"
              }`}>
              <MapPin className="w-4 h-4 text-red-500 shrink-0" />
              <div className="text-left min-w-0">
                <p className={`text-[7px] uppercase font-black font-mono tracking-widest ${textMuted}`}>TO STATION</p>
                <p className={`font-black text-xs truncate max-w-[170px] ${d ? "text-slate-100" : "text-slate-800"}`}>{destName} ({destCode})</p>
              </div>
              <ChevronDown className={`w-3.5 h-3.5 ${textMuted} ml-auto shrink-0`} />
            </button>

            <AnimatePresence>
              {showDestDrop && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
                  className={`absolute right-0 top-full mt-2.5 w-80 backdrop-blur-2xl border rounded-2xl p-3 z-[60] space-y-2 ${dropBg}`}>
                  <p className={`text-[7.5px] font-black uppercase tracking-widest font-mono px-1 ${textMuted}`}>SELECT DESTINATION RAILWAY TERMINAL</p>
                  <div className={`relative flex items-center border rounded-xl px-1 py-1 ${inputBg}`}>
                    <Search className={`w-3.5 h-3.5 absolute left-3 ${textMuted}`} />
                    <input type="text" autoFocus placeholder="Station name, code, state..." value={destQuery} onChange={e => setDestQuery(e.target.value)}
                      onClick={e => e.stopPropagation()}
                      className={`w-full pl-8 pr-2 py-1 bg-transparent text-xs font-bold outline-none ${
                        d ? "text-slate-200 placeholder:text-slate-500" : "text-slate-850 placeholder:text-slate-400"
                      }`} />
                  </div>
                  <div className="max-h-56 overflow-y-auto space-y-0.5 scrollbar-thin">
                    {filteredDest.map(st => (
                      <button key={st.code} disabled={st.code === originCode}
                        onClick={() => { setDestCode(st.code); setDestName(st.name); setDestQuery(""); setShowDestDrop(false); }}
                        className={`w-full text-left px-2.5 py-2.5 rounded-xl text-xs flex items-center justify-between transition-all ${
                          destCode === st.code ? d ? "bg-orange-500/20 text-white border border-orange-500/30" : "bg-orange-55 text-orange-750 border border-orange-200 font-bold"
                          : d ? "text-slate-300 hover:bg-white/5 border border-transparent" : "text-slate-650 hover:bg-slate-50 border border-transparent"
                        } ${st.code === originCode ? "opacity-30 cursor-not-allowed" : "cursor-pointer"}`}>
                        <div className="truncate">
                          <span className="font-black">{st.name}</span>
                          <span className={`ml-1.5 text-[8.5px] font-extrabold uppercase ${d ? "text-indigo-400" : "text-indigo-600"}`}>
                            ({getStateForStation(st.code, st.name)})
                          </span>
                        </div>
                        <span className={`text-[10px] font-mono shrink-0 font-bold ${textMuted}`}>{st.code}</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className={`hidden lg:block h-8 w-[1px] ${d ? "bg-white/5" : "bg-slate-200"}`} />

          {/* Date Picker */}
          <div className="flex items-center gap-3 px-4 py-3 rounded-2xl min-w-[155px]">
            <Calendar className="w-4 h-4 text-orange-500 shrink-0" />
            <div className="text-left">
              <p className={`text-[7px] uppercase font-black font-mono tracking-widest ${textMuted}`}>JOURNEY DATE</p>
              <input
                type="date"
                value={searchDate}
                onChange={e => setSearchDate(e.target.value)}
                className={`bg-transparent outline-none font-black text-xs border-none p-0 cursor-pointer ${
                  d ? "text-slate-100" : "text-slate-850"
                }`}
                style={{ colorScheme: d ? 'dark' : 'light' }}
              />
            </div>
          </div>

          {/* Search CTA */}
          <button onClick={() => handleSearch()}
            className="flex items-center justify-center gap-1.5 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-orange-500 to-red-600 text-white text-xs font-black uppercase tracking-wider font-mono cursor-pointer hover:opacity-95 active:scale-[0.98] transition-all shadow-[0_4px_16px_rgba(249,115,22,0.3)] min-w-[120px] self-stretch">
            <Search className="w-4 h-4" />
            <span>Search</span>
          </button>
        </div>
      </section>

      {/* ═══ RESPONSIVE 3-COLUMN LAYOUT ═══ */}
      <main className="max-w-[1680px] mx-auto p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-12 gap-5 h-[calc(100vh-140px)] overflow-hidden">
        
        {/* ── LEFT COLUMN: COLLAPSIBLE FILTERS & QUICK LOOKUPS (width: 3/12) ── */}
        <section className="lg:col-span-3 flex flex-col h-full overflow-y-auto space-y-4 pr-1 scrollbar-thin select-none">
          
          {/* Quick Timetable timetable lookup */}
          <div className={`border rounded-2xl p-4 transition-all duration-300 shrink-0 ${
            d ? "bg-[#0E1220]/60 border-white/5" : "bg-white border-slate-200/80 shadow-sm"
          }`}>
            <div className="flex items-center gap-2 mb-2.5">
              <Compass className="w-4 h-4 text-orange-500" />
              <h3 className={`text-[9px] font-black uppercase tracking-widest font-mono ${d ? "text-slate-300" : "text-slate-700"}`}>
                Live Train Timetable
              </h3>
            </div>
            <div className="flex gap-1.5">
              <input
                type="text"
                placeholder="Train number (e.g. 12980)..."
                value={cockpitTrainNo}
                onChange={(e) => setCockpitTrainNo(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") handleDirectTrainLookup(); }}
                className={`flex-1 px-3 py-2.5 text-xs font-mono font-bold rounded-xl border outline-none transition-all ${
                  d
                    ? "bg-slate-950/60 border-white/5 text-slate-100 placeholder-slate-600 focus:border-orange-500/50"
                    : "bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-orange-400"
                }`}
              />
              <button
                onClick={() => handleDirectTrainLookup()}
                className={`px-3 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-wider font-mono cursor-pointer transition-all ${
                  d ? "bg-orange-500/15 hover:bg-orange-500/25 text-orange-400 border border-orange-500/30" : "bg-orange-600 hover:bg-orange-700 text-white"
                }`}
              >
                Scan
              </button>
              <button
                onClick={() => handleMapRouteLookup()}
                disabled={loadingMapRoute}
                className={`px-3.5 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-wider font-mono cursor-pointer transition-all flex items-center justify-center ${
                  d ? "bg-red-500/15 hover:bg-red-500/25 text-red-400 border border-red-500/30" : "bg-red-650 hover:bg-red-750 text-white"
                }`}
              >
                {loadingMapRoute ? "..." : "Map"}
              </button>
            </div>
          </div>

          {/* Premium Collapsible Filters */}
          <div className={`border rounded-2xl transition-all duration-300 overflow-hidden shrink-0 ${
            d ? "bg-[#0E1220]/60 border-white/5" : "bg-white border-slate-200/80 shadow-sm"
          }`}>
            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={`w-full flex items-center justify-between p-4 text-[9px] font-black tracking-widest uppercase font-mono transition-all ${
                d ? "hover:bg-white/5 text-slate-300" : "hover:bg-slate-50 text-slate-700"
              }`}
            >
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-orange-500" />
                <span>Filters Console</span>
              </div>
              <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${showAdvancedFilters ? "rotate-180" : ""}`} />
            </button>

            <AnimatePresence initial={false}>
              {showAdvancedFilters && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className={`p-4 border-t space-y-4 ${d ? "border-white/5" : "border-slate-100 bg-slate-50/20"}`}>
                    
                    {/* Budget Slider */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className={`text-[8px] font-black uppercase tracking-wider ${d ? "text-slate-400" : "text-slate-500"}`}>Budget Cap</label>
                        <span className="text-[10px] font-black font-mono text-orange-500">₹{maxBudget.toLocaleString("en-IN")}</span>
                      </div>
                      <input
                        type="range"
                        min="300"
                        max="8000"
                        step="100"
                        value={maxBudget}
                        onChange={(e) => setMaxBudget(Number(e.target.value))}
                        className="w-full h-1 bg-slate-850 rounded-lg appearance-none cursor-pointer accent-orange-500"
                      />
                    </div>

                    {/* Classes Preferred */}
                    <div className="space-y-2">
                      <label className={`text-[8px] font-black uppercase tracking-wider block ${d ? "text-slate-400" : "text-slate-500"}`}>Coach Select</label>
                      <div className="flex flex-wrap gap-1">
                        {["SL", "3A", "2A", "1A", "CC", "EC"].map(coach => {
                          const active = selectedCoaches.includes(coach);
                          return (
                            <button
                              key={coach}
                              onClick={() => {
                                if (active) {
                                  setSelectedCoaches(selectedCoaches.filter(c => c !== coach));
                                } else {
                                  setSelectedCoaches([...selectedCoaches, coach]);
                                }
                              }}
                              className={`px-2 py-1 rounded-lg text-[9px] font-bold border transition-all cursor-pointer ${
                                active
                                  ? "bg-orange-500/10 border-orange-500 text-orange-400"
                                  : d ? "bg-slate-950 border-white/5 text-slate-400 hover:bg-slate-905" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                              }`}
                            >
                              {coach}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Departure Slot selections */}
                    <div className="space-y-2">
                      <label className={`text-[8px] font-black uppercase tracking-wider block ${d ? "text-slate-400" : "text-slate-500"}`}>Departure Time</label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {[
                          { id: "Morning", label: "Morning (6am-12pm)" },
                          { id: "Afternoon", label: "Afternoon (12pm-6pm)" },
                          { id: "Evening", label: "Evening (6pm-12am)" },
                          { id: "Night", label: "Night (12am-6am)" }
                        ].map(slot => {
                          const active = selectedSlots.includes(slot.id);
                          return (
                            <button
                              key={slot.id}
                              onClick={() => {
                                if (active) {
                                  setSelectedSlots(selectedSlots.filter(s => s !== slot.id));
                                } else {
                                  setSelectedSlots([...selectedSlots, slot.id]);
                                }
                              }}
                              className={`px-2.5 py-1.5 rounded-lg text-[8.5px] font-bold border transition-all cursor-pointer text-left ${
                                active
                                  ? "bg-orange-500/10 border-orange-500 text-orange-400"
                                  : d ? "bg-slate-950 border-white/5 text-slate-400 hover:bg-slate-905" : "bg-white border-slate-200 text-slate-650 hover:bg-slate-50"
                              }`}
                            >
                              {slot.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Train type filter */}
                    <div className="space-y-2">
                      <label className={`text-[8px] font-black uppercase tracking-wider block ${d ? "text-slate-400" : "text-slate-500"}`}>Train Tier Type</label>
                      <div className="flex flex-wrap gap-1">
                        {["Vande Bharat", "Rajdhani", "Shatabdi", "Duronto", "Express"].map(type => {
                          const active = selectedTrainTypes.includes(type);
                          return (
                            <button
                              key={type}
                              onClick={() => {
                                if (active) {
                                  setSelectedTrainTypes(selectedTrainTypes.filter(t => t !== type));
                                } else {
                                  setSelectedTrainTypes([...selectedTrainTypes, type]);
                                }
                              }}
                              className={`px-2 py-1 rounded-lg text-[9px] font-bold border transition-all cursor-pointer ${
                                active
                                  ? "bg-red-500/10 border-red-500 text-red-400"
                                  : d ? "bg-slate-950 border-white/5 text-slate-400 hover:bg-slate-905" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                              }`}
                            >
                              {type}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Transfers limit */}
                    <div className="grid grid-cols-2 gap-3.5">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <label className={`text-[8px] font-black uppercase tracking-wider ${d ? "text-slate-400" : "text-slate-500"}`}>Max Transfers</label>
                          <span className={`text-[10px] font-mono font-bold ${d ? "text-slate-300" : "text-slate-700"}`}>{maxTransfers}</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="2"
                          step="1"
                          value={maxTransfers}
                          onChange={(e) => setMaxTransfers(Number(e.target.value))}
                          className="w-full h-1 bg-slate-850 rounded-lg appearance-none cursor-pointer accent-orange-500"
                        />
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <label className={`text-[8px] font-black uppercase tracking-wider ${d ? "text-slate-400" : "text-slate-500"}`}>Max Layover</label>
                          <span className={`text-[10px] font-mono font-bold ${d ? "text-slate-300" : "text-slate-700"}`}>{maxLayover}h</span>
                        </div>
                        <input
                          type="range"
                          min="1"
                          max="12"
                          step="1"
                          value={maxLayover}
                          onChange={(e) => setMaxLayover(Number(e.target.value))}
                          className="w-full h-1 bg-slate-850 rounded-lg appearance-none cursor-pointer accent-orange-500"
                        />
                      </div>
                    </div>

                    {/* Confirmed seat filters */}
                    <div className="flex items-center justify-between pt-2.5 border-t border-dashed border-slate-500/10">
                      <label className="flex items-center gap-2 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={confirmedOnly}
                          onChange={(e) => setConfirmedOnly(e.target.checked)}
                          className="rounded border-slate-700 text-orange-500 focus:ring-orange-500 bg-slate-900 w-4 h-4 cursor-pointer"
                        />
                        <span className={`text-[9px] font-black uppercase tracking-wider ${d ? "text-slate-350" : "text-slate-700"}`}>Confirmed Seats (75%+)</span>
                      </label>

                      <button
                        onClick={() => {
                          setMaxBudget(8000);
                          setSelectedCoaches(["SL", "3A", "2A", "1A", "CC", "EC"]);
                          setSelectedSlots([]);
                          setSelectedTrainTypes(["Vande Bharat", "Rajdhani", "Shatabdi", "Duronto", "Express"]);
                          setMaxTransfers(2);
                          setMaxLayover(8);
                          setConfirmedOnly(false);
                        }}
                        className={`text-[8px] font-black uppercase font-mono px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                          d ? "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300" : "bg-slate-100 border-slate-300 hover:bg-slate-200 text-slate-700"
                        }`}
                      >
                        Reset
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </section>

        {/* ── CENTER COLUMN: TRAIN RESULT LISTINGS (width: 5/12) ── */}
        <section className="lg:col-span-5 flex flex-col h-full overflow-y-auto space-y-4 pr-1 scrollbar-thin select-none">
          
          {/* Category Tabs */}
          <div className={`p-1 rounded-2xl flex border w-full overflow-x-auto shrink-0 scrollbar-none gap-0.5 select-none ${
            d ? "bg-slate-950/80 border-white/5" : "bg-slate-100 border-slate-250"
          }`}>
            {[
              { id: "ai", label: "AI Pick", icon: Sparkles },
              { id: "split", label: "Smart Split", icon: Cpu },
              { id: "direct", label: "Direct Only", icon: Train },
              { id: "cheapest", label: "Cheapest", icon: Compass },
              { id: "premium", label: "Premium Tier", icon: Activity }
            ].map(tab => {
              const active = activeTab === tab.id;
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 py-2 px-2.5 rounded-xl text-[10px] font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
                    active
                      ? d
                        ? "bg-[#111625] border border-white/5 text-orange-400 shadow-[inset_0_1px_2px_rgba(255,255,255,0.05)] font-bold"
                        : "bg-white border border-slate-200/50 text-orange-650 shadow-sm font-black"
                      : d ? "text-slate-400 hover:text-slate-200" : "text-slate-500 hover:text-slate-800"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0 text-orange-500" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Priority Sort selection */}
          <div className={`p-2 rounded-2xl border flex items-center justify-between gap-3 text-xs shadow-sm shrink-0 select-none ${
            d ? "bg-[#0E1220]/60 border-white/5" : "bg-white border-slate-200"
          }`}>
            <div className="flex items-center gap-1.5 pl-2">
              <Activity className="w-3.5 h-3.5 text-orange-500" />
              <span className={`text-[8.5px] font-black uppercase tracking-wider font-mono ${d ? "text-slate-400" : "text-slate-500"}`}>
                Priority Sort
              </span>
            </div>
            <div className={`p-0.5 rounded-xl flex border gap-0.5 ${
              d ? "bg-slate-950 border-white/5" : "bg-slate-100 border-slate-200"
            }`}>
              {[
                { id: "money", label: "💵 Cheapest" },
                { id: "time", label: "⚡ Shortest Time" }
              ].map(option => {
                const active = sortBy === option.id;
                return (
                  <button
                    key={option.id}
                    onClick={() => setSortBy(option.id as any)}
                    className={`py-1.5 px-3 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer ${
                      active
                        ? d
                          ? "bg-[#111625] text-orange-400 border border-white/5"
                          : "bg-white text-orange-650 border border-slate-250/50 shadow-sm"
                        : d ? "text-slate-400 hover:text-slate-200" : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    {option.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Train listings list */}
          <div className="space-y-4 flex-1">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
                <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
                <div>
                  <p className="text-xs font-black uppercase tracking-widest text-orange-500 animate-pulse font-mono">Scanning live telemetry...</p>
                  <p className={`text-[10px] ${textMuted} font-mono mt-1`}>Resolving platform mapping & real-time seats...</p>
                </div>
              </div>
            ) : errorMsg ? (
              <div className="flex flex-col items-center justify-center text-center p-8 border rounded-2xl border-red-500/20 bg-red-500/5">
                <AlertCircle className="w-8 h-8 text-red-500 mb-2" />
                <p className="text-xs font-black uppercase tracking-wider">Telemetry Error</p>
                <p className={`text-[10px] ${textSec} mt-1`}>{errorMsg}</p>
                <button onClick={() => handleSearch()} className="mt-4 px-3.5 py-2 bg-red-500 text-white rounded-xl text-xs font-bold font-mono">Retry</button>
              </div>
            ) : filteredAndSortedRoutes.length > 0 ? (
              filteredAndSortedRoutes.map((route) => (
                <RouteCard
                  key={route.id}
                  route={route}
                  isSelected={selectedId === route.id}
                  onSelect={setSelectedId}
                  isDark={d}
                  selectedClass={selectedClass}
                  setSelectedClass={setSelectedClass}
                />
              ))
            ) : (
              <div className="text-center py-16 border border-dashed rounded-2xl border-slate-500/10">
                <Compass className="w-10 h-10 text-orange-500 opacity-20 mx-auto mb-3" />
                <p className="text-xs font-black">No trains match</p>
                <p className="text-[9px] text-slate-500 mt-1">Adjust filters or budgets to see options</p>
              </div>
            )}
          </div>
        </section>

        {/* ── RIGHT COLUMN: MAP & AI INSIGHTS & TIMELINES (width: 4/12) ── */}
        <section className={`lg:col-span-4 flex flex-col h-full border rounded-3xl backdrop-blur-2xl overflow-hidden relative transition-all duration-500 ${panelBg}`}>
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-orange-500 to-transparent opacity-40" />

          {selectedRoute ? (
            <>
              {/* Panel Header */}
              <div className={`px-5 py-4 border-b flex items-center justify-between shrink-0 ${dividerColor}`}>
                <div>
                  <div className="flex items-center gap-2">
                    {selectedRoute.isRecommended && (
                      <span className="text-[8px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-orange-500/15 text-orange-400 border border-orange-500/20 font-mono">
                        AI Recommended Pick
                      </span>
                    )}
                    <span className="text-[8.5px] font-mono font-bold text-slate-500">
                      {selectedRoute.legs.filter(l => l.type === 'train').length} SEGMENT{selectedRoute.legs.filter(l => l.type === 'train').length > 1 ? 'S' : ''}
                    </span>
                  </div>
                  <h2 className={`text-sm font-extrabold tracking-tight mt-1 truncate max-w-[220px] ${d ? "text-white" : "text-slate-900"}`}>{selectedRoute.name}</h2>
                </div>
                <div className="text-right shrink-0">
                  <p className={`text-[7px] uppercase font-bold font-mono tracking-wider ${textMuted}`}>COMBINED FARE</p>
                  <p className="text-base font-black font-mono bg-gradient-to-r from-orange-500 to-red-600 bg-clip-text text-transparent">₹{currentFare.toLocaleString("en-IN")}</p>
                </div>
              </div>

              {/* Scrollable details */}
              <div className="flex-1 overflow-y-auto scrollbar-thin space-y-4 pb-6 select-none">
                
                {/* 1. India Map */}
                <div className="p-4 pb-0">
                  <div className="h-64 rounded-2xl overflow-hidden relative border border-slate-500/10">
                    <div className="absolute top-3 left-3 z-[10] px-2.5 py-1 rounded-lg bg-black/75 backdrop-blur-md border border-white/10 text-[8px] font-bold text-white flex items-center gap-1.5 shadow-lg font-mono uppercase tracking-wider">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-ping" />
                      <span>Telemetry Route</span>
                    </div>

                    <IndiaRouteMap 
                      isDarkMode={d} 
                      routeStops={mapStops} 
                      originCode={originCode} 
                      destCode={destCode} 
                      selectedRoute={activeSelectedRoute} 
                      onSelectOrigin={(code, name) => { setOriginCode(code); setOriginName(name); }}
                      onSelectDest={(code, name) => { setDestCode(code); setDestName(name); }}
                    />
                  </div>
                </div>

                {/* 2. AI Smart Recommendation Panel */}
                <div className="px-4">
                  <div className={`p-4 rounded-2xl border relative overflow-hidden backdrop-blur-xl ${
                    d ? "bg-gradient-to-tr from-purple-950/20 via-orange-950/15 to-red-950/10 border-orange-500/20 shadow-[0_4px_30px_rgba(249,115,22,0.05)]" 
                      : "bg-gradient-to-tr from-purple-50 via-orange-50 to-red-50 border-orange-100 shadow-sm"
                  }`}>
                    <div className="flex items-center justify-between mb-3 border-b border-slate-500/10 pb-2">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-orange-500 animate-pulse" />
                        <h3 className={`text-[9px] font-black uppercase tracking-widest font-mono ${d ? "text-orange-300" : "text-orange-800"}`}>
                          AI SMART RECOMMENDATION
                        </h3>
                      </div>
                      <span className="text-[9px] font-mono font-bold text-emerald-500 uppercase">
                        {selectedRoute.type === "split" ? "💰 SAVES 18%" : "⚡ FASTEST"}
                      </span>
                    </div>

                    <div className="space-y-2">
                      <p className={`text-xs leading-relaxed font-bold ${d ? "text-slate-200" : "text-slate-700"}`}>
                        {selectedRoute.type === "split" 
                          ? `Circumvent waitlist caps by booking segment halts. Smart Split routes Patna Express with Ajmer Shatabdi. Transfer Lounge synced.` 
                          : `Sleek high-priority direct connection. Minimizes transfers. Highly recommended for business travelers.`}
                      </p>
                      <div className="flex items-center gap-3 pt-2 text-[9px] font-mono font-bold text-slate-400">
                        <div className="flex items-center gap-1 text-emerald-500">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>92%+ Seats Confirmed</span>
                        </div>
                        <span>•</span>
                        <div className="flex items-center gap-1 text-orange-500">
                          <Clock className="w-3.5 h-3.5" />
                          <span>LoungeSync OK</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3. Interactive Class Fare Matrix */}
                <div className="px-4 space-y-2">
                  <h4 className={`text-[8.5px] font-black uppercase tracking-widest font-mono ${textMuted}`}>Fare Matrix & Availability</h4>
                  <div className="grid grid-cols-3 gap-2">
                    {(selectedRoute.classes && selectedRoute.classes.length > 0 ? selectedRoute.classes : ["SL", "3A", "2A", "1A"]).map((c) => {
                      const fare = getClassFare(selectedRoute.price, c);
                      const isSelected = selectedClass === c;
                      const avails = get6DayAvailability(selectedRoute.id, c, searchDate);
                      const primary = avails[0] || { type: "avail", status: "AVAILABLE-15" };

                      let statusColor = "text-emerald-500 bg-emerald-500/10 border-emerald-500/20";
                      if (primary.type === "wl") statusColor = "text-red-500 bg-red-500/10 border-red-500/20";
                      else if (primary.type === "rac") statusColor = "text-amber-500 bg-amber-500/10 border-amber-500/20";

                      return (
                        <button
                          key={c}
                          onClick={() => setSelectedClass(c)}
                          className={`p-3 rounded-2xl border text-left cursor-pointer transition-all flex flex-col justify-between h-20 ${
                            isSelected
                              ? d
                                ? "bg-orange-500/10 border-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.15)]"
                                : "bg-orange-50 border-orange-500 shadow-md font-bold"
                              : d
                                ? "bg-slate-900/50 border-white/5 hover:border-slate-800"
                                : "bg-slate-50 border-slate-200 hover:border-slate-350"
                          }`}
                        >
                          <div className="w-full flex items-center justify-between">
                            <span className={`text-xs font-black font-mono ${d ? "text-slate-200" : "text-slate-850"}`}>{c}</span>
                            <span className={`text-[9px] font-mono font-black ${d ? "text-slate-100" : "text-slate-900"}`}>₹{fare}</span>
                          </div>
                          <span className={`w-full py-0.5 rounded text-[8px] font-black font-mono border text-center truncate uppercase ${statusColor}`}>
                            {primary.status}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 4. Timeline details halts */}
                <div className="px-4 space-y-3">
                  <h4 className={`text-[8.5px] font-black uppercase tracking-widest font-mono ${textMuted}`}>Route halt timeline</h4>
                  <div className="relative pl-6 space-y-4">
                    <div className={`absolute left-2.5 top-2 bottom-2 w-[2px] ${d ? "bg-slate-850" : "bg-slate-200"}`} />

                    {selectedRoute.legs.map((leg, i) => leg.type === "train" ? (
                      <div key={i} className="relative">
                        <div className="absolute -left-[20px] top-1.5 w-3 h-3 rounded-full border-2 border-orange-500 bg-[#090B11] shadow-[0_0_8px_rgba(249,115,22,0.4)]" />
                        <TrainLegCard leg={leg} baseDate={searchDate} isDark={d} parentSelectedClass={selectedClass} />
                      </div>
                    ) : (
                      <div key={i} className="relative">
                        <div className="absolute -left-[20px] top-2 w-3 h-3 rounded-full border-2 border-red-500 bg-[#090B11] shadow-[0_0_8px_rgba(239,68,68,0.4)]" />
                        <TransferLogisticsCard leg={leg} isDark={d} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-col h-full items-center justify-center p-8 text-center space-y-4 select-none">
              <Compass className="w-12 h-12 text-orange-500 opacity-20 animate-spin-slow" />
              <div>
                <h3 className="text-xs font-black uppercase tracking-widest">Route Details HUD</h3>
                <p className={`text-[10px] ${textSec} mt-1 max-w-xs`}>
                  Select any train card on the results column to load full 6-day telemetry, live seat probability, and routing timeline diagnostics.
                </p>
              </div>
            </div>
          )}
        </section>
      </main>

      {/* ═══ BOTTOM STICKY BOOKING BAR ═══ */}
      {selectedRoute && (
        <div className="fixed bottom-4 left-4 right-4 z-40 flex justify-center pointer-events-none select-none">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className={`w-full max-w-4xl rounded-3xl backdrop-blur-2xl border px-6 py-4 flex flex-wrap md:flex-nowrap items-center justify-between gap-4 pointer-events-auto shadow-2xl relative overflow-hidden ${
              d ? "bg-[#0C101F]/90 border-orange-500/20 shadow-[0_12px_40px_rgba(0,0,0,0.6)]" : "bg-white/95 border-orange-200 shadow-[0_10px_35px_rgba(0,0,0,0.06)]"
            }`}
          >
            {/* Soft pulsing glow behind floating booking bar */}
            {d && <div className="absolute inset-0 bg-radial-gradient from-orange-500/5 to-transparent pointer-events-none" />}

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-orange-500 to-red-600 flex items-center justify-center shadow-lg shrink-0">
                <Train className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <p className={`text-[8px] uppercase font-black font-mono tracking-widest ${textMuted}`}>SELECTED ITINERARY</p>
                <h4 className={`text-xs font-black truncate max-w-[280px] ${d ? "text-slate-100" : "text-slate-900"}`}>
                  {selectedRoute.name}
                </h4>
                <p className={`text-[9px] font-mono font-bold text-slate-500 mt-0.5`}>
                  Class: <span className="text-orange-500">{selectedClass}</span> • Date: {searchDate} • 1 Passenger
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 pt-3 md:pt-0 border-slate-500/10">
              <div className="text-left md:text-right">
                <p className={`text-[8px] uppercase font-black font-mono tracking-widest ${textMuted}`}>ESTIMATED FARE</p>
                <p className="text-lg font-mono font-black bg-gradient-to-r from-orange-500 to-red-650 bg-clip-text text-transparent">₹{currentFare.toLocaleString("en-IN")}</p>
              </div>

              <a
                href="https://www.irctc.co.in"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  const textToCopy = `TRAINWISE ITINERARY BOOKING\nRoute: ${selectedRoute.name}\nClass: ${selectedClass}\nDate: ${searchDate}\nPrice: ₹${currentFare}`;
                  navigator.clipboard.writeText(textToCopy);
                }}
                className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-orange-500 to-red-600 hover:opacity-95 text-white text-xs font-black uppercase tracking-wider font-mono cursor-pointer transition-all active:scale-[0.98] shadow-[0_4px_15px_rgba(249,115,22,0.3)] animate-pulse"
              >
                <span>Book on IRCTC</span>
                <ExternalLink className="w-3.5 h-3.5 shrink-0" />
              </a>
            </div>
          </motion.div>
        </div>
      )}

      {/* ═══ VIEW TIMETABLE SCHEDULER MODAL ═══ */}
      <AnimatePresence>
        {globalShowTimetableModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md bg-black/60 select-none">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-4xl rounded-3xl border overflow-hidden flex flex-col h-[85vh] ${
                d ? "bg-[#0B0F19] border-white/10 text-slate-200" : "bg-white border-slate-350 text-slate-800 shadow-2xl"
              }`}
            >
              {/* Header */}
              <div className={`p-4 border-b flex items-center justify-between ${dividerColor}`}>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-orange-500/10 flex items-center justify-center">
                    <Train className="w-4 h-4 text-orange-500" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider font-mono">Live Telemetry Train Schedule</h3>
                    <p className={`text-[10px] ${textMuted} font-mono mt-0.5`}>Scanned directly from IRCTC core system endpoints</p>
                  </div>
                </div>
                <button
                  onClick={() => setGlobalShowTimetableModal(false)}
                  className={`w-8 h-8 rounded-full border flex items-center justify-center cursor-pointer transition-all hover:bg-slate-500/10 ${dividerColor}`}
                >
                  <X className="w-4 h-4 text-slate-500" />
                </button>
              </div>

              {/* Scroll Content */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
                {globalLoadingSchedule ? (
                  <div className="flex flex-col items-center justify-center py-24 space-y-3">
                    <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
                    <p className="text-xs font-black uppercase tracking-wider text-orange-500 animate-pulse font-mono">Contacting IRCTC proxy terminal...</p>
                  </div>
                ) : globalLookupError ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center space-y-3">
                    <AlertCircle className="w-8 h-8 text-red-500" />
                    <p className="text-xs font-black uppercase tracking-wider text-red-500">Scan lookup failed</p>
                    <p className={`text-[10px] ${textSec} font-mono max-w-sm`}>{globalLookupError}</p>
                  </div>
                ) : globalScheduleData ? (
                  <div className="space-y-4">
                    <div className={`p-4 rounded-2xl border flex items-center justify-between ${d ? "bg-slate-900/50 border-white/5" : "bg-slate-50 border-slate-200"}`}>
                      <div>
                        <h4 className="text-sm font-black uppercase">{globalScheduleData.trainNo} - {globalScheduleData.trainName}</h4>
                        <p className={`text-[9px] font-mono mt-1 ${textMuted}`}>Route: {globalScheduleData.route[0]?.stationName} ➜ {globalScheduleData.route[globalScheduleData.route.length - 1]?.stationName}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {isAnimating ? (
                          <button
                            onClick={stopRouteAnimation}
                            className="px-3 py-1.5 bg-red-650 hover:bg-red-750 text-white rounded-xl text-[9px] font-black uppercase tracking-wider font-mono flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <Square className="w-3 h-3 fill-white" /> Stop Auto-scan
                          </button>
                        ) : (
                          <button
                            onClick={() => startRouteAnimation(globalScheduleData.route, 'global')}
                            className="px-3 py-1.5 bg-gradient-to-r from-orange-500 to-red-600 hover:opacity-95 text-white rounded-xl text-[9px] font-black uppercase tracking-wider font-mono flex items-center gap-1.5 cursor-pointer transition-all"
                          >
                            <Play className="w-3 h-3 fill-white" /> Live Route Tour
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="border rounded-2xl overflow-hidden">
                      <table className="w-full border-collapse text-left text-[11px] font-bold">
                        <thead>
                          <tr className={`border-b text-[8.5px] font-black font-mono uppercase tracking-widest ${d ? "bg-slate-950 border-white/5 text-slate-400" : "bg-slate-50 border-slate-200 text-slate-500"}`}>
                            <th className="p-3 pl-4">Halt</th>
                            <th className="p-3">Station</th>
                            <th className="p-3">Arr / Dep</th>
                            <th className="p-3">Dist</th>
                            <th className="p-3">Fare</th>
                            <th className="p-3">Pf</th>
                            <th className="p-3 pr-4 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {globalScheduleData.route.map((stop: any, idx: number) => {
                            const isCurrentHalt = idx === animatingIdx;
                            const totalDistance = parseFloat(globalScheduleData.route[globalScheduleData.route.length - 1]?.distance || "1") || 1;
                            const stopDistance = parseFloat(stop.distance) || 0;
                            const isSameTrain = selectedRoute && (selectedRoute.legs.some(l => l.number === globalScheduleData.trainNo) || selectedRoute.id === globalScheduleData.trainNo);
                            const basePrice = isSameTrain ? (selectedRoute.price * (stopDistance / totalDistance)) : (stopDistance * 1.5);
                            const stopFare = stopDistance > 0 ? `₹${getClassFare(basePrice, selectedClass || "3A")}` : "Base";
                            return (
                              <tr
                                key={idx}
                                id={`global-station-row-${idx}`}
                                className={`border-b transition-all duration-300 ${d ? "border-white/5" : "border-slate-100"} ${
                                  isCurrentHalt ? d ? "bg-orange-500/10 text-orange-400" : "bg-orange-50 text-orange-700 font-black" : ""
                                }`}
                              >
                                <td className="p-3 pl-4 font-mono text-[10px]">{stop.haltNo}</td>
                                <td className="p-3">
                                  <span>{stop.stationName}</span>
                                  <span className={`ml-1 text-[8.5px] font-mono ${textMuted}`}>({stop.stnCode})</span>
                                </td>
                                <td className="p-3 font-mono text-[10px]">{stop.arrivalTime} / {stop.departureTime}</td>
                                <td className="p-3 font-mono text-[10px]">{stop.distance} km</td>
                                <td className="p-3 font-mono text-[10px]">{stopFare}</td>
                                <td className="p-3">
                                  <span className={`text-[8px] font-mono px-1 rounded ${d ? "bg-slate-900 border border-white/5 text-slate-400" : "bg-slate-100 border border-slate-250 text-slate-500"}`}>{stop.platform || "Pf #1"}</span>
                                </td>
                                <td className="p-3 pr-4 text-right">
                                  <button
                                    onClick={() => handleBookSegment(stop.stationName, globalScheduleData.route[globalScheduleData.route.length - 1]?.stationName, stop.stnCode, globalScheduleData.route[globalScheduleData.route.length - 1]?.stnCode)}
                                    className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider font-mono border transition-all cursor-pointer ${
                                      d ? "bg-slate-900 border-white/5 hover:border-orange-500/30 text-slate-350" : "bg-white border-slate-250 text-slate-650 hover:bg-slate-50"
                                    }`}
                                  >
                                    Book Halt
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <p className="text-center py-20 text-xs text-slate-500 font-mono">No telemetry timetable resolved.</p>
                )}
              </div>

              {/* Footer */}
              <div className={`p-4 border-t text-[8px] font-mono text-slate-500 flex items-center justify-between ${dividerColor}`}>
                <span>Segment booking automagically copies details to simplify official IRCTC checkout</span>
                <span className="flex items-center gap-1.5 text-emerald-500">
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                  100% Secure Telemetry
                </span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ═══ REAL-TIME PNR SEARCH MODAL ═══ */}
      <AnimatePresence>
        {showPnrModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md bg-black/60 select-none">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-2xl rounded-3xl border overflow-hidden flex flex-col ${
                d ? "bg-[#0B0F19] border-white/10 text-slate-200" : "bg-white border-slate-350 text-slate-800 shadow-2xl"
              }`}
            >
              {/* Header */}
              <div className={`p-4 border-b flex items-center justify-between ${dividerColor}`}>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-orange-500/10 flex items-center justify-center">
                    <Train className="w-4 h-4 text-orange-500 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider font-mono">Real-Time PNR Search Cockpit</h3>
                    <p className={`text-[10px] ${textMuted} font-mono mt-0.5`}>Scans reservation tables directly from IRCTC endpoints</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowPnrModal(false)}
                  className={`w-8 h-8 rounded-full border flex items-center justify-center cursor-pointer transition-all hover:bg-slate-500/10 ${dividerColor}`}
                >
                  <X className="w-4 h-4 text-slate-500" />
                </button>
              </div>

              {/* Content */}
              <div className="p-5 space-y-4">
                <div className="flex gap-2">
                  <input
                    type="text"
                    maxLength={10}
                    placeholder="Enter 10-Digit PNR number..."
                    value={pnrNumber}
                    onChange={(e) => setPnrNumber(e.target.value.replace(/\D/g, ''))}
                    onKeyDown={(e) => { if (e.key === "Enter") handleCheckPnr(); }}
                    className={`flex-1 px-4 py-3 text-sm font-mono font-bold rounded-2xl border outline-none transition-all ${
                      d
                        ? "bg-slate-950/80 border-white/10 text-slate-100 placeholder-slate-600 focus:border-orange-500"
                        : "bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-orange-500"
                    }`}
                  />
                  <button
                    onClick={handleCheckPnr}
                    className="px-6 py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-red-600 hover:opacity-95 text-white text-xs font-black uppercase tracking-wider font-mono cursor-pointer transition-all shadow-md"
                  >
                    Scan PNR
                  </button>
                </div>

                {pnrLoading ? (
                  <div className="flex flex-col items-center justify-center py-16 space-y-3">
                    <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
                    <p className="text-xs font-black uppercase tracking-wider text-orange-500 animate-pulse font-mono">Contacting IRCTC servers...</p>
                  </div>
                ) : pnrError ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center space-y-2 border border-red-500/20 bg-red-500/5 rounded-2xl">
                    <AlertCircle className="w-7 h-7 text-red-500" />
                    <p className="text-xs font-black uppercase tracking-wider text-red-500">Search Error</p>
                    <p className={`text-[10px] ${textSec} font-mono max-w-sm`}>{pnrError}</p>
                  </div>
                ) : pnrResult ? (
                  <div className={`p-4 rounded-2xl border ${d ? "bg-slate-900/40 border-white/5" : "bg-slate-50 border-slate-250 shadow-inner"} space-y-3.5`}>
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-500/10 pb-2">
                      <div>
                        <span className={`text-[8px] font-black uppercase font-mono tracking-widest ${d ? "text-orange-400" : "text-orange-600"}`}>PNR: {pnrResult.pnr}</span>
                        <h4 className="text-xs font-black uppercase mt-0.5">{pnrResult.trainNo} - {pnrResult.trainName}</h4>
                      </div>
                      <span className="text-[10px] font-mono font-black bg-gradient-to-r from-orange-500 to-red-650 bg-clip-text text-transparent">{pnrResult.dateOfJourney}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-[10px] font-bold">
                      <div>
                        <span className={`block text-[7.5px] uppercase ${textMuted}`}>Route Leg</span>
                        <span className={`block text-xs font-black mt-0.5 ${d ? "text-slate-200" : "text-slate-800"}`}>{pnrResult.from} ➜ {pnrResult.to}</span>
                      </div>
                      <div>
                        <span className={`block text-[7.5px] uppercase ${textMuted}`}>Class Code</span>
                        <span className={`block text-xs font-black mt-0.5 ${d ? "text-slate-200" : "text-slate-800"}`}>{pnrResult.classType}</span>
                      </div>
                    </div>

                    <div className="border rounded-xl overflow-hidden mt-3 text-[10px] font-bold">
                      <table className="w-full text-left">
                        <thead>
                          <tr className={`border-b text-[7.5px] font-black font-mono uppercase tracking-widest ${d ? "bg-slate-950/80 border-white/5 text-slate-400" : "bg-slate-100 border-slate-200 text-slate-500"}`}>
                            <th className="p-2 pl-3">Passenger</th>
                            <th className="p-2">Booking Status</th>
                            <th className="p-2 pr-3 text-right">Current Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {pnrResult.passengers.map((p: any, idx: number) => {
                            const isConfirmed = p.currentStatus.toLowerCase().includes("cnf") || p.currentStatus.toLowerCase().includes("avail");
                            return (
                              <tr key={idx} className={`border-b ${d ? "border-white/5" : "border-slate-100"}`}>
                                <td className="p-2 pl-3 font-mono text-[9.5px]">#{p.passengerNo}</td>
                                <td className="p-2 font-mono text-[9.5px] opacity-75">{p.bookingStatus}</td>
                                <td className={`p-2 pr-3 text-right font-mono text-[9.5px] ${isConfirmed ? "text-emerald-500" : "text-amber-500"}`}>{p.currentStatus}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <p className="text-center py-10 text-[10px] text-slate-500 font-mono">No active PNR scanned.</p>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ═══ VIEW BOOKINGS MODAL ═══ */}
      <AnimatePresence>
        {showBookingsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md bg-black/60 select-none">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-3xl rounded-3xl border overflow-hidden flex flex-col h-[75vh] ${
                d ? "bg-[#0B0F19] border-white/10 text-slate-200" : "bg-white border-slate-350 text-slate-800 shadow-2xl"
              }`}
            >
              {/* Header */}
              <div className={`p-4 border-b flex items-center justify-between ${dividerColor}`}>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-orange-500/10 flex items-center justify-center">
                    <Calendar className="w-4 h-4 text-orange-500" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider font-mono">My Bookings Cockpit</h3>
                    <p className={`text-[10px] ${textMuted} font-mono mt-0.5`}>Your pre-populated segment telemetry checkout histories</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowBookingsModal(false)}
                  className={`w-8 h-8 rounded-full border flex items-center justify-center cursor-pointer transition-all hover:bg-slate-500/10 ${dividerColor}`}
                >
                  <X className="w-4 h-4 text-slate-500" />
                </button>
              </div>

              {/* Bookings scroll contents */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
                {[
                  { pnr: "4209823485", train: "Jaipur Rajdhani Express (12957)", date: "2026-07-15", class: "3A", route: "JP ➜ NDLS", price: "₹2,150", status: "CNB / Confirmed" },
                  { pnr: "7820194825", train: "Vande Bharat Express (22436)", date: "2026-07-20", class: "EC", route: "NDLS ➜ BSB", price: "₹2,440", status: "CNB / Confirmed" },
                  { pnr: "1930284920", train: "Kalka Shatabdi + Toy Train", date: "2026-07-25", class: "CC", route: "NDLS ➜ SML", price: "₹3,840", status: "Leg 1 CNB • Leg 2 RAC" }
                ].map((booking, idx) => (
                  <div key={idx} className={`p-4 rounded-2xl border ${d ? "bg-slate-900/50 border-white/5 hover:border-slate-800" : "bg-slate-50 border-slate-200 hover:border-slate-350"} flex items-center justify-between gap-4`}>
                    <div className="text-left">
                      <span className={`text-[8px] font-black uppercase tracking-widest font-mono ${d ? "text-orange-400" : "text-orange-600"}`}>PNR: {booking.pnr}</span>
                      <h4 className="text-xs font-black uppercase mt-0.5">{booking.train}</h4>
                      <p className={`text-[9px] font-mono text-slate-500 mt-1`}>
                        Route: {booking.route} • Class: {booking.class} • Date: {booking.date}
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="text-xs font-mono font-black bg-gradient-to-r from-orange-500 to-red-650 bg-clip-text text-transparent">{booking.price}</p>
                      <span className="block text-[8.5px] font-mono text-emerald-500 mt-1 uppercase font-bold">{booking.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ═══ TELEMETRY CONSOLE MODAL ═══ */}
      <AnimatePresence>
        {showTelemetryModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md bg-black/60 select-none">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-2xl rounded-3xl border overflow-hidden flex flex-col ${
                d ? "bg-[#0B0F19] border-white/10 text-slate-200" : "bg-white border-slate-350 text-slate-800 shadow-2xl"
              }`}
            >
              {/* Header */}
              <div className={`p-4 border-b flex items-center justify-between ${dividerColor}`}>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-orange-500/10 flex items-center justify-center">
                    <Activity className="w-4 h-4 text-orange-500 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider font-mono">Pilot Telemetry Diagnostics</h3>
                    <p className={`text-[10px] ${textMuted} font-mono mt-0.5`}>Real-time API integrations, response latency, and system configs</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowTelemetryModal(false)}
                  className={`w-8 h-8 rounded-full border flex items-center justify-center cursor-pointer transition-all hover:bg-slate-500/10 ${dividerColor}`}
                >
                  <X className="w-4 h-4 text-slate-500" />
                </button>
              </div>

              {/* Content logs */}
              <div className="p-5 space-y-4 font-mono text-[10px] text-left leading-relaxed">
                <div className={`p-4 rounded-xl border ${d ? "bg-black/45 border-white/5" : "bg-slate-100 border-slate-200"}`}>
                  <div className="flex items-center gap-2 mb-2 text-orange-500 font-black">
                    <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
                    <span>SYSTEM ONLINE (STATUS: 200 OK)</span>
                  </div>
                  <div className="space-y-1 opacity-80">
                    <p>➜ CORE ROUTING ENGINE: Active multi-hop search algorithms v3.4.1</p>
                    <p>➜ IRCTC DATA COUPLING: Proxy secure SSL socket tunnel active</p>
                    <p>➜ TELEMETRY LATENCY: 24ms (Patna - Delhi - Jaipur routing loop resolved)</p>
                    <p>➜ SYSTEM MEMORY LOAD: 18.2 MB / 512 MB client thread</p>
                  </div>
                </div>

                <div className={`p-4 rounded-xl border ${d ? "bg-black/45 border-white/5" : "bg-slate-100 border-slate-200"} space-y-1`}>
                  <p className="text-indigo-400 font-bold">➜ ACTIVE WEBSOCKET EVENTS LOGS:</p>
                  <p className="opacity-75">[14:48:35] SEARCH_QUERY: FROM=PNBE TO=SML (TRAVEL_DATE=2026-07-15)</p>
                  <p className="opacity-75">[14:48:36] SEARCH_RESPONSE: Resolved 3 optimal itineraries (durations=18h - 28h)</p>
                  <p className="opacity-75">[14:48:36] AI_RECOM_RESOLVER: Smart Pick resolved with 92% confirmation odds</p>
                  <p className="opacity-75">[14:48:38] PILOT_PROFILE_SYNCED: User "Garv Tandon" session active</p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ═══ AUTHENTICATION MODAL ═══ */}
      <AnimatePresence>
        {showAuthModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md bg-black/60 select-none">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-md rounded-3xl border overflow-hidden flex flex-col p-5 ${
                d ? "bg-[#0B0F19] border-white/10 text-slate-200" : "bg-white border-slate-350 text-slate-800 shadow-2xl"
              }`}
            >
              <div className="flex items-center justify-between border-b border-slate-500/10 pb-3.5 mb-4">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-orange-500" />
                  <h3 className="text-xs font-black uppercase tracking-wider font-mono">
                    {authTab === "signin" ? "Sign In Cockpit" : "Create Pilot Profile"}
                  </h3>
                </div>
                <button
                  onClick={() => setShowAuthModal(false)}
                  className={`w-7 h-7 rounded-full border flex items-center justify-center cursor-pointer transition-all hover:bg-slate-500/10 ${dividerColor}`}
                >
                  <X className="w-3.5 h-3.5 text-slate-500" />
                </button>
              </div>

              {authError && (
                <div className="mb-4 p-3 border rounded-xl border-red-500/20 bg-red-500/5 text-red-500 text-[10px] font-bold font-mono">
                  {authError}
                </div>
              )}

              <form onSubmit={authTab === "signin" ? handleSignIn : handleSignUp} className="space-y-3.5">
                {authTab === "signup" && (
                  <div className="space-y-1">
                    <label className={`text-[8.5px] font-black uppercase tracking-wider ${textMuted}`}>Full Name</label>
                    <input
                      type="text"
                      placeholder="e.g. Garv Tandon"
                      value={authName}
                      onChange={(e) => setAuthName(e.target.value)}
                      className={`w-full px-3.5 py-3 text-xs font-bold rounded-xl border outline-none transition-all ${
                        d ? "bg-slate-950/60 border-white/5 text-slate-100 placeholder-slate-650" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                )}

                <div className="space-y-1">
                  <label className={`text-[8.5px] font-black uppercase tracking-wider ${textMuted}`}>Email Address</label>
                  <input
                    type="email"
                    placeholder="e.g. garv@trainwise.com"
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    className={`w-full px-3.5 py-3 text-xs font-bold rounded-xl border outline-none transition-all ${
                      d ? "bg-slate-950/60 border-white/5 text-slate-100 placeholder-slate-650" : "bg-slate-50 border-slate-200 text-slate-900"
                    }`}
                  />
                </div>

                <div className="space-y-1">
                  <label className={`text-[8.5px] font-black uppercase tracking-wider ${textMuted}`}>Security Password</label>
                  <input
                    type="password"
                    placeholder="Enter security key..."
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    className={`w-full px-3.5 py-3 text-xs font-bold rounded-xl border outline-none transition-all ${
                      d ? "bg-slate-950/60 border-white/5 text-slate-100 placeholder-slate-650" : "bg-slate-50 border-slate-200 text-slate-900"
                    }`}
                  />
                </div>

                <button
                  type="submit"
                  disabled={authIsLoading}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-red-650 hover:opacity-95 text-white text-xs font-black uppercase tracking-wider font-mono cursor-pointer transition-all mt-6 shadow-md"
                >
                  {authIsLoading ? "Authorizing Security..." : authTab === "signin" ? "Verify Credentials" : "Issue Pilot Passkey"}
                </button>
              </form>

              <div className="mt-5 pt-4 border-t border-slate-500/10 text-center space-y-4">
                <span className={`text-[9px] font-black uppercase tracking-widest font-mono block ${textMuted}`}>⚡ OR CONTINUE WITH SECURE OAUTH</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleOAuthLogin("google")}
                    className={`py-2 rounded-xl text-[10px] font-bold border cursor-pointer transition-all flex items-center justify-center gap-1.5 ${
                      d ? "bg-slate-900 border-white/5 text-slate-300 hover:bg-slate-800" : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    <span>Google Secure</span>
                  </button>
                  <button
                    onClick={() => handleOAuthLogin("passkey")}
                    className={`py-2 rounded-xl text-[10px] font-bold border cursor-pointer transition-all flex items-center justify-center gap-1.5 ${
                      d ? "bg-slate-900 border-white/5 text-slate-300 hover:bg-slate-800" : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    <span>Pilot Passkey</span>
                  </button>
                </div>

                <div className="text-[10px] font-bold mt-4">
                  {authTab === "signin" ? (
                    <p className={textSec}>
                      New to TrainWise?{" "}
                      <button onClick={() => setAuthTab("signup")} className="text-orange-500 hover:underline">
                        Create Pilot Profile
                      </button>
                    </p>
                  ) : (
                    <p className={textSec}>
                      Already have a profile?{" "}
                      <button onClick={() => setAuthTab("signin")} className="text-orange-500 hover:underline">
                        Verify Credentials
                      </button>
                    </p>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════
// DYNAMIC ROUTE CARD COMPONENT (REDESIGNED!)
// ═══════════════════════════════════════════

function RouteCard({
  route,
  isSelected,
  onSelect,
  isDark,
  selectedClass,
  setSelectedClass
}: {
  route: TrainRoute;
  isSelected: boolean;
  onSelect: (id: string) => void;
  isDark: boolean;
  selectedClass: string;
  setSelectedClass: (cls: string) => void;
}) {
  const d = isDark;
  const isRec = route.isRecommended;
  const textMuted = d ? "text-slate-500" : "text-slate-400";
  const textSec = d ? "text-slate-400" : "text-slate-500";

  const baseBg = isRec
    ? isSelected
      ? d ? "bg-[#1C1722]/90 border-orange-500 shadow-[0_0_30px_rgba(249,115,22,0.15)]" : "bg-orange-50/70 border-orange-500 shadow-[0_0_25px_rgba(249,115,22,0.1)]"
      : d ? "bg-[#1A1116]/30 border-orange-500/10 hover:border-orange-500/30" : "bg-orange-50/20 border-orange-200 hover:border-orange-350 shadow-sm"
    : isSelected
      ? d ? "bg-[#111625]/90 border-orange-500 shadow-[0_0_25px_rgba(249,115,22,0.1)]" : "bg-orange-50/30 border-orange-550 shadow-[0_0_20px_rgba(249,115,22,0.06)]"
      : d ? "bg-[#111625]/50 border-white/5 hover:border-orange-500/25" : "bg-white border-slate-200/70 hover:border-slate-350 shadow-sm";

  const accentColor = isRec ? "#EF4444" : "#F97316";

  // Determine train thumbnail based on category names
  const getTrainThumbnail = (name = "") => {
    const lName = name.toLowerCase();
    if (lName.includes("vande bharat")) {
      return (
        <svg className="w-full h-full text-orange-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      );
    } else if (lName.includes("rajdhani") || lName.includes("shatabdi")) {
      return (
        <svg className="w-full h-full text-[#F97316]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
        </svg>
      );
    }
    return (
      <svg className="w-full h-full text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
      </svg>
    );
  };

  return (
    <motion.div
      onClick={() => onSelect(route.id)}
      whileHover={{ y: -3, scale: 1.002 }}
      className={`relative p-5 rounded-3xl border transition-all duration-300 cursor-pointer ${baseBg}`}
    >
      {/* Glow tags */}
      {isRec && route.tag && (
        <div className="absolute -top-3 left-5 bg-gradient-to-r from-orange-500 to-red-650 text-white text-[7.5px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-[0_0_12px_rgba(249,115,22,0.35)] flex items-center gap-1 border border-white/10">
          <Sparkles className="w-2.5 h-2.5 animate-pulse" />
          <span>{route.tag}</span>
        </div>
      )}

      {/* Side Active marker */}
      {isSelected && (
        <div
          className="absolute left-0 top-6 bottom-6 w-1 rounded-r-full"
          style={{ backgroundColor: accentColor, boxShadow: `0 0 12px ${accentColor}80` }}
        />
      )}

      <div className="flex items-start gap-4">
        {/* Sleek Train Thumbnail */}
        <div className={`w-11 h-11 rounded-2xl border flex items-center justify-center shrink-0 ${
          d ? "bg-slate-950/60 border-white/5" : "bg-slate-50 border-slate-200"
        }`}>
          {getTrainThumbnail(route.name)}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <h3 className={`text-xs sm:text-sm font-black tracking-tight truncate ${d ? "text-slate-100" : "text-slate-900"}`}>
              {route.name}
            </h3>
            {route.legs[0]?.number && (
              <span className={`px-2 py-0.5 rounded font-mono text-[8px] font-black tracking-wide border ${
                d ? "bg-slate-900 border-white/5 text-slate-400" : "bg-slate-100 border-slate-250 text-slate-500"
              }`}>
                #{route.legs[0].number}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 mt-2 text-[9px] font-mono font-bold flex-wrap">
            {route.preview.map((code, i) => (
              <React.Fragment key={code + i}>
                <span className={`px-2 py-0.5 rounded ${
                  isRec && code === route.preview[route.preview.length - 1] ? "bg-orange-500/10 text-orange-400 border border-orange-500/25 font-bold"
                  : d ? "bg-slate-950/80 border border-white/5 text-slate-350" : "bg-slate-100 border border-slate-200 text-slate-600"
                }`}>
                  {getStationName(code, code)}
                </span>
                {i < route.preview.length - 1 && <ArrowRight className={`w-3.5 h-3.5 shrink-0 text-orange-500`} />}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Price and value highlights */}
        <div className="text-right shrink-0">
          <span className="text-base font-black font-mono bg-gradient-to-r from-orange-500 to-red-650 bg-clip-text text-transparent">₹{route.price.toLocaleString("en-IN")}</span>
          {isRec && <span className="block text-[7.5px] font-black uppercase tracking-wider text-emerald-500 font-mono mt-0.5">BEST PICK</span>}
        </div>
      </div>

      {/* Fare matrices grid inside route card */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mt-4 pt-4 border-t border-dashed border-slate-500/10">
        {(route.classes && route.classes.length > 0 ? route.classes.slice(0, 6) : ["SL", "3A", "2A", "1A"]).map((cls) => {
          const fare = getClassFare(route.price, cls);
          const avails = get6DayAvailability(route.id, cls, "");
          const primary = avails[0] || { type: "avail", status: "AVAILABLE" };
          const isSelectedClass = selectedClass === cls && isSelected;

          let badgeColor = "text-emerald-500 bg-emerald-500/10 border-emerald-500/15";
          if (primary.type === "wl") badgeColor = "text-red-500 bg-red-500/10 border-red-500/15";
          else if (primary.type === "rac") badgeColor = "text-amber-500 bg-amber-500/10 border-amber-500/15";

          return (
            <div
              key={cls}
              onClick={(e) => {
                e.stopPropagation();
                onSelect(route.id);
                setSelectedClass(cls);
              }}
              className={`p-2 rounded-xl border text-left cursor-pointer transition-all flex flex-col justify-between h-[52px] ${
                isSelectedClass
                  ? d
                    ? "bg-orange-500/10 border-orange-500 shadow-md"
                    : "bg-orange-50 border-orange-500 shadow-sm font-bold"
                  : d
                    ? "bg-slate-950/60 border-white/5 hover:border-slate-800"
                    : "bg-slate-50 border-slate-200 hover:border-slate-350"
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span className={`text-[9px] font-black font-mono ${d ? "text-slate-300" : "text-slate-700"}`}>{cls}</span>
                <span className={`text-[9px] font-mono font-bold ${d ? "text-slate-200" : "text-slate-900"}`}>₹{fare}</span>
              </div>
              <span className={`text-[7.5px] font-black font-mono block rounded border text-center truncate px-0.5 mt-1 uppercase ${badgeColor}`}>
                {primary.status}
              </span>
            </div>
          );
        })}
      </div>

      {/* Timings,Platform details */}
      <div className={`flex items-center justify-between mt-4 pt-3 border-t ${d ? "border-white/5" : "border-slate-100"}`}>
        <div className={`flex items-center gap-3.5 text-[9px] font-mono ${textSec}`}>
          <span className="flex items-center gap-1 font-bold">
            <Clock className="w-3.5 h-3.5 text-orange-500" />
            <span>{route.totalDuration}</span>
          </span>
          <span>•</span>
          <span>{route.transfers === 0 ? "Direct Transit" : `${route.transfers} Change${route.transfers > 1 ? 's' : ''}`}</span>
        </div>
        
        <button
          onClick={(e) => { e.stopPropagation(); onSelect(route.id); }}
          className={`text-[9.5px] font-black uppercase font-mono px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1 cursor-pointer ${
            isSelected
              ? "text-white shadow-md"
              : d ? "bg-slate-900 text-slate-400 hover:bg-slate-850" : "bg-slate-100 text-slate-650 hover:bg-slate-200"
          }`}
          style={isSelected ? { backgroundImage: `linear-gradient(to right, #f97316, #ef4444)` } : {}}
        >
          <span>Cockpit view</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════
// HELPER: 6-DAY SEATS AVAILABILITY GENERATOR
// ═══════════════════════════════════════════
function get6DayAvailability(trainNo: string, coachClass: string, baseDateStr: string) {
  const days = [];
  const baseDate = new Date(baseDateStr || "2026-07-15");
  const classCode = coachClass.split(" ")[0] || "3A";
  
  for (let i = 0; i < 6; i++) {
    const d = new Date(baseDate);
    d.setDate(baseDate.getDate() + i);
    const dateString = d.toLocaleDateString("en-US", { month: "short", day: "numeric", weekday: "short" });
    
    let hash = 5381;
    const seed = trainNo + classCode + i;
    for (let j = 0; j < seed.length; j++) {
      hash = ((hash << 5) + hash) + seed.charCodeAt(j);
    }
    
    const mod = Math.abs(hash) % 100;
    let status = "";
    let type: "avail" | "rac" | "wl" = "avail";
    let odds = 100;

    if (mod < 45) {
      const seats = (mod % 35) + 3;
      status = `AVAILABLE-${seats}`;
      type = "avail";
      odds = 100;
    } else if (mod < 70) {
      const racNo = (mod % 8) + 1;
      status = `RAC-${racNo}`;
      type = "rac";
      odds = 90 - (racNo * 4);
    } else {
      const wlNo = (mod % 18) + 1;
      status = `WL-${wlNo}`;
      type = "wl";
      odds = Math.max(12, 85 - (wlNo * 5));
    }

    days.push({
      date: dateString,
      status,
      type,
      odds
    });
  }
  return days;
}

function generateSeatsForCoach(trainNo: string, coachClass: string, coachName: string) {
  const cleanClass = coachClass.trim().toUpperCase().split(" ")[0];
  let totalSeats = 72;
  if (cleanClass === "1A") totalSeats = 22;
  else if (cleanClass === "2A") totalSeats = 46;
  else if (cleanClass === "CC" || cleanClass === "EC") totalSeats = 78;

  const seats = [];
  let hash = 5381;
  const seed = trainNo + coachClass + coachName;
  for (let i = 0; i < seed.length; i++) {
    hash = ((hash << 5) + hash) + seed.charCodeAt(i);
  }

  for (let s = 1; s <= totalSeats; s++) {
    const seatHash = (hash * s) % 100;
    let isBooked = seatHash < 60;
    let genderPref = "";
    if (isBooked) {
      genderPref = (seatHash % 3 === 0) ? "female" : (seatHash % 3 === 1) ? "male" : "senior";
    }

    let berthType = "LB";
    if (cleanClass === "CC" || cleanClass === "EC") {
      const col = (s - 1) % 6;
      if (col === 0 || col === 5) berthType = "Window";
      else if (col === 1 || col === 4) berthType = "Middle";
      else berthType = "Aisle";
    } else {
      const typeMod = (s - 1) % 8;
      if (typeMod === 0 || typeMod === 3) berthType = "LB";
      else if (typeMod === 1 || typeMod === 4) berthType = "MB";
      else if (typeMod === 2 || typeMod === 5) berthType = "UB";
      else if (typeMod === 6) berthType = "SL";
      else berthType = "SU";
    }

    seats.push({
      seatNo: s,
      berthType,
      isBooked,
      genderPref,
      isHandicap: (s === 2 && cleanClass !== "1A"),
    });
  }
  return seats;
}

// ═══════════════════════════════════════════
// TIMELINE DETAILED TIMETABLE SEGMENT HALTS
// ═══════════════════════════════════════════

function TrainLegCard({
  leg,
  baseDate,
  isDark,
  parentSelectedClass
}: {
  leg: RouteLeg;
  baseDate: string;
  isDark: boolean;
  parentSelectedClass?: string;
}) {
  const d = isDark;
  const activeClass = parentSelectedClass || "3A";
  const [loadingSchedule, setLoadingSchedule] = useState(false);
  const [scheduleData, setScheduleData] = useState<any>(null);
  const [lookupError, setLookupError] = useState("");
  const [expanded, setExpanded] = useState(false);

  const [simulatedCapacityPercent, setSimulatedCapacityPercent] = useState(72);
  const [selectedCoach, setSelectedCoach] = useState("B1");
  const [simulatedSeats, setSimulatedSeats] = useState<any[]>([]);

  const textMuted = d ? "text-slate-500" : "text-slate-400";
  const textSec = d ? "text-slate-400" : "text-slate-500";
  const dividerColor = d ? "border-white/5" : "border-slate-100";

  const handleBookSegment = (stopFrom: string, stopTo: string, stnFromCode: string, stnToCode: string) => {
    const textToCopy = `TRAINWISE BOOKING CREDENTIALS\nFrom: ${stopFrom} (${stnFromCode})\nTo: ${stopTo} (${stnToCode})\nClass: ${activeClass}\nDate: ${baseDate}`;
    navigator.clipboard.writeText(textToCopy);
    window.open("https://www.irctc.co.in/nget/train-search", "_blank");
  };

  const loadHaltSchedule = async () => {
    if (scheduleData) {
      setExpanded(!expanded);
      return;
    }

    setLoadingSchedule(true);
    setLookupError("");
    setExpanded(true);
    try {
      const res = await fetch("/api/schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trainNo: leg.number })
      });
      const json = await res.json();
      if (json && json.success && json.data) {
        setScheduleData(json.data);
      } else {
        setLookupError("Core telemetry database is currently resolving quotas. Tap below to retry.");
      }
    } catch (e) {
      setLookupError("Failed to scanned live schedule endpoints.");
    } finally {
      setLoadingSchedule(false);
    }
  };

  const coachList = useMemo(() => {
    const cleanClass = activeClass.trim().toUpperCase().split(" ")[0];
    if (cleanClass === "SL") return ["S1", "S2", "S3", "S4", "S5", "S6"];
    if (cleanClass === "3A") return ["B1", "B2", "B3", "B4", "B5"];
    if (cleanClass === "2A") return ["A1", "A2"];
    if (cleanClass === "1A") return ["H1"];
    if (cleanClass === "CC") return ["C1", "C2", "C3"];
    return ["EC1"];
  }, [activeClass]);

  useEffect(() => {
    if (expanded) {
      const initialCoach = coachList[0] || "B1";
      setSelectedCoach(initialCoach);
      const seats = generateSeatsForCoach(leg.number || "12980", activeClass, initialCoach);
      setSimulatedSeats(seats);
      const bookedCount = seats.filter(s => s.isBooked).length;
      setSimulatedCapacityPercent(Math.round((bookedCount / seats.length) * 100));
    }
  }, [expanded, coachList, leg.number, activeClass]);

  const handleCoachSelect = (coach: string) => {
    setSelectedCoach(coach);
    const seats = generateSeatsForCoach(leg.number || "12980", activeClass, coach);
    setSimulatedSeats(seats);
    const bookedCount = seats.filter(s => s.isBooked).length;
    setSimulatedCapacityPercent(Math.round((bookedCount / seats.length) * 100));
  };

  const isVandeBharat = leg.name?.toLowerCase().includes("vande bharat");

  return (
    <div className={`p-4 rounded-3xl border relative overflow-hidden transition-all ${
      d ? "bg-[#111625]/60 border-white/5 shadow-2xl" : "bg-white border-slate-250/70 shadow-sm"
    }`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-orange-500 to-red-650 flex items-center justify-center shadow-lg shrink-0">
            <Train className="w-5 h-5 text-white" />
          </div>
          <div className="text-left">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h4 className={`text-xs font-black uppercase ${d ? "text-slate-100" : "text-slate-850"}`}>{leg.name}</h4>
              <span className={`text-[8.5px] font-mono font-bold px-1.5 py-0.2 rounded border ${
                d ? "bg-slate-900 border-white/5 text-slate-400" : "bg-slate-50 border-slate-200 text-slate-500"
              }`}>#{leg.number}</span>
            </div>
            <p className={`text-[9.5px] mt-1 ${textSec} font-medium`}>
              Departure: <span className="font-mono font-bold text-orange-500">{leg.depTime}</span> from <span className="font-bold">{leg.from}</span>
            </p>
            <p className={`text-[9.5px] ${textSec} font-medium`}>
              Arrival: <span className="font-mono font-bold text-orange-500">{leg.arrTime}</span> at <span className="font-bold">{leg.to}</span>
            </p>
          </div>
        </div>

        <div className="text-right shrink-0">
          <span className={`text-[8.5px] font-mono font-black block border rounded-full px-2 py-0.5 bg-orange-500/10 border-orange-500/25 text-orange-400 uppercase`}>
            {isVandeBharat ? "VANDE BHARAT TIER" : "EXPRESS TIER"}
          </span>
          <span className={`text-[9.5px] font-mono ${textMuted} block mt-1`}>{leg.duration} Duration</span>
        </div>
      </div>

      {/* Detailed Halt Schedule trigger dropdown */}
      <div className="mt-4 pt-3 border-t border-dashed border-slate-500/10 flex items-center justify-between">
        <button
          onClick={loadHaltSchedule}
          className={`text-[9.5px] font-black uppercase font-mono px-3.5 py-2 rounded-xl transition-all cursor-pointer inline-flex items-center gap-1.5 ${
            d ? "bg-slate-900 border-white/5 hover:border-slate-800 text-slate-350" : "bg-slate-100 border-slate-250 text-slate-650 hover:bg-slate-200"
          }`}
        >
          <Compass className="w-3.5 h-3.5 text-orange-500" />
          <span>{expanded ? "Close Cockpit Halts" : "Open Seat & Station Halts"}</span>
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${expanded ? "rotate-180" : ""}`} />
        </button>

        <a
          href="https://www.irctc.co.in"
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => {
            const textToCopy = `TRAINWISE BOOKING CREDENTIALS\nTrain: #${leg.number} ${leg.name}\nFrom: ${leg.from}\nTo: ${leg.to}\nClass: ${activeClass}`;
            navigator.clipboard.writeText(textToCopy);
          }}
          className={`px-3.5 py-2 rounded-xl text-[9.5px] font-black uppercase font-mono transition-all inline-flex items-center gap-1 cursor-pointer bg-gradient-to-r from-orange-500 to-red-600 hover:opacity-95 text-white`}
        >
          <span>Book segment</span>
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>

      {/* Expanded stops detail panel */}
      {expanded && (
        <div className={`mt-4 pt-4 border-t border-dashed ${dividerColor} space-y-4`}>
          {loadingSchedule ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 className="w-5 h-5 text-orange-500 animate-spin mr-2" />
              <span className="text-[10px] font-mono font-bold animate-pulse text-orange-500 uppercase">Resolving IRCTC endpoints...</span>
            </div>
          ) : lookupError ? (
            <div className="text-center py-4 text-[9.5px] text-red-500 font-mono">{lookupError}</div>
          ) : scheduleData ? (
            <div className="space-y-4">
              
              {/* 1. Dynamic Interactive Seat Layout simulator */}
              <div className={`p-4 rounded-2xl border ${d ? "bg-slate-950/65 border-white/5" : "bg-slate-50 border-slate-250 shadow-inner"}`}>
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-500/10 mb-3.5">
                  <div>
                    <span className="text-[7.5px] font-black uppercase font-mono tracking-widest text-orange-400">Seat Telemetry Simulator</span>
                    <h5 className={`text-[10.5px] font-black ${d ? "text-slate-100" : "text-slate-900"}`}>
                      Coach <span className="text-orange-500 font-mono">{selectedCoach}</span> ({activeClass} Layout)
                    </h5>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-mono font-bold text-slate-500">Select Coach:</span>
                    <div className="flex gap-1 overflow-x-auto max-w-[140px] scrollbar-none">
                      {coachList.map(c => (
                        <button
                          key={c}
                          onClick={() => handleCoachSelect(c)}
                          className={`px-2 py-0.5 rounded text-[8px] font-mono font-black border transition-all cursor-pointer ${
                            selectedCoach === c
                              ? "bg-orange-500 text-white border-transparent"
                              : d ? "bg-slate-900 border-white/5 text-slate-400" : "bg-white border-slate-250 text-slate-650"
                          }`}
                        >
                          {c}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Seat Capacity indicators */}
                <div className="grid grid-cols-2 gap-3.5 text-[9px] font-bold mb-4">
                  <div className={`p-2.5 rounded-xl border ${d ? "bg-slate-900/50 border-white/5" : "bg-white border-slate-200"}`}>
                    <span className="block opacity-65 font-mono text-[7px]">Simulated Coach Load</span>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className={`w-2 h-2 rounded-full ${simulatedCapacityPercent > 80 ? "bg-red-500 animate-pulse" : "bg-emerald-500 animate-pulse"}`} />
                      <span className={simulatedCapacityPercent > 80 ? "text-red-400" : "text-emerald-400"}>{simulatedCapacityPercent}% Capacity</span>
                    </div>
                  </div>
                  <div className={`p-2.5 rounded-xl border ${d ? "bg-slate-900/50 border-white/5" : "bg-white border-slate-200"}`}>
                    <span className="block opacity-65 font-mono text-[7px]">Seat preferences</span>
                    <span className="block font-black mt-0.5 text-slate-400 font-mono">LB=Lower, SU=Side Upper</span>
                  </div>
                </div>

                {/* Seat visual map */}
                <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto p-1.5 border rounded-xl border-dashed border-slate-500/10">
                  {simulatedSeats.map((s: any) => {
                    let seatColor = "bg-emerald-500/15 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/30";
                    if (s.isBooked) {
                      seatColor = "bg-slate-500/10 border-slate-700/30 text-slate-500 cursor-not-allowed";
                    }
                    if (s.isHandicap) {
                      seatColor = "bg-indigo-500/20 border-indigo-500/40 text-indigo-400 font-black";
                    }
                    return (
                      <div
                        key={s.seatNo}
                        title={`Seat ${s.seatNo} [${s.berthType}] ${s.isBooked ? "Booked" : "Vacant"}`}
                        className={`w-6 h-6 rounded flex flex-col items-center justify-center text-[7px] font-mono font-bold border transition-all ${seatColor}`}
                      >
                        <span>{s.seatNo}</span>
                        <span className="text-[5.5px] opacity-60 leading-none">{s.berthType}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 2. Detailed halts listing */}
              <div className="border rounded-2xl overflow-hidden mt-3 text-[10px] font-bold">
                <table className="w-full text-left">
                  <thead>
                    <tr className={`border-b text-[8px] font-black font-mono uppercase tracking-widest ${d ? "bg-slate-950/80 border-white/5 text-slate-400" : "bg-slate-100 border-slate-200 text-slate-500"}`}>
                      <th className="p-2 pl-3">Stop</th>
                      <th className="p-2">Station Name</th>
                      <th className="p-2">Arr / Dep</th>
                      <th className="p-2">Dist</th>
                      <th className="p-2">Fare</th>
                      <th className="p-2">Pf</th>
                      <th className="p-2 pr-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scheduleData.route.map((stop: any, idx: number) => {
                      const fromCode = leg.from.match(/\(([^)]+)\)/)?.[1] || leg.from;
                      const toCode = leg.to.match(/\(([^)]+)\)/)?.[1] || leg.to;
                      
                      const isSourceHalt = stop.stnCode.toUpperCase() === fromCode.toUpperCase().trim();
                      const isDestHalt = stop.stnCode.toUpperCase() === toCode.toUpperCase().trim();

                      const totalDistance = parseFloat(scheduleData.route[scheduleData.route.length - 1]?.distance || "1") || 1;
                      const stopDistance = parseFloat(stop.distance) || 0;
                      const basePrice = leg.price ? (leg.price * (stopDistance / totalDistance)) : (stopDistance * 1.5);
                      const stopFare = stopDistance > 0 ? `₹${getClassFare(basePrice, activeClass)}` : "Base";

                      return (
                        <tr
                          key={idx}
                          className={`border-b ${d ? "border-white/5" : "border-slate-100"} ${
                            isSourceHalt || isDestHalt ? d ? "bg-orange-500/10 text-orange-400" : "bg-orange-50 text-orange-700 font-black" : ""
                          }`}
                        >
                          <td className="p-2 pl-3 font-mono text-[9px]">{stop.haltNo}</td>
                          <td className="p-2">
                            <span>{stop.stationName}</span>
                            <span className={`ml-1 text-[8px] font-mono ${textMuted}`}>({stop.stnCode})</span>
                          </td>
                          <td className="p-2 font-mono text-[9px]">{stop.arrivalTime} / {stop.departureTime}</td>
                          <td className="p-2 font-mono text-[9px]">{stop.distance} km</td>
                          <td className="p-2 font-mono text-[9px]">{stopFare}</td>
                          <td className="p-2">
                            <span className={`text-[7.5px] font-mono px-1 rounded ${d ? "bg-slate-900 border border-white/5 text-slate-400" : "bg-slate-100 border border-slate-250 text-slate-500"}`}>{stop.platform || "Pf #1"}</span>
                          </td>
                          <td className="p-2 pr-3 text-right">
                            <button
                              onClick={() => handleBookSegment(stop.stationName, leg.to.split(" (")[0], stop.stnCode, toCode)}
                              className={`px-2 py-0.5 rounded text-[8.5px] font-black uppercase tracking-wider font-mono border transition-all cursor-pointer ${
                                d ? "bg-slate-900 border-white/5 hover:border-orange-500/30 text-slate-350" : "bg-white border-slate-250 text-slate-650 hover:bg-slate-50"
                              }`}
                            >
                              Book Leg
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════
// COMPONENT: TRANSFER LOGISTICS CARD
// ═══════════════════════════════════════════
function TransferLogisticsCard({ leg, isDark }: { leg: RouteLeg; isDark: boolean }) {
  const d = isDark;
  const textSec = d ? "text-slate-450" : "text-slate-555";
  
  const fromCode = leg.from.match(/\(([^)]+)\)/)?.[1] || leg.from;
  const toCode = leg.to.match(/\(([^)]+)\)/)?.[1] || leg.to;
  const isDifferentStation = fromCode.toUpperCase().trim() !== toCode.toUpperCase().trim();
  
  const walkingMinutes = Math.round(10 + (leg.duration.charCodeAt(0) % 5));
  const distanceMeters = walkingMinutes * 60;
  const fromPlatform = (leg.duration.charCodeAt(1) % 5) + 1;
  const toPlatform = (leg.duration.charCodeAt(2) % 6) + 1;
  const delayRiskPercentage = (leg.duration.charCodeAt(3) % 12) + 1;
  
  const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(leg.from)}&destination=${encodeURIComponent(leg.to)}&travelmode=driving`;
  
  return (
    <div className={`border border-dashed rounded-2xl p-4 flex flex-col gap-3 relative overflow-hidden transition-all ${
      d ? "bg-[#0E1B1D]/40 border-red-500/20" : "bg-red-50/20 border-red-200 shadow-sm"
    }`}>
      <div className="flex items-start gap-3">
        <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
          d ? "bg-red-500/10 border border-red-500/20" : "bg-red-50 border border-red-100"
        }`}>
          {isDifferentStation ? (
            <Compass className="w-4 h-4 text-orange-500" />
          ) : (
            <Coffee className="w-4 h-4 text-red-500 animate-pulse" />
          )}
        </div>
        <div className="flex-1 text-left">
          <div className="flex items-center gap-2 flex-wrap">
            <h4 className={`text-[10px] font-black uppercase tracking-wider ${d ? "text-red-400" : "text-red-800"}`}>
              {isDifferentStation ? `Inter-station Transit` : `Platform Transit at ${leg.from.split(" ")[0]}`}
            </h4>
            <span className="text-[8px] font-black px-2 py-0.5 rounded-full font-mono bg-red-500/15 border border-red-500/20 text-red-400">
              {isDifferentStation ? "45 mins" : leg.duration} Transition
            </span>
          </div>
          <p className={`text-[9.5px] mt-1 leading-relaxed ${textSec}`}>
            {isDifferentStation 
              ? `Different terminals transit required between ${leg.from} and ${leg.to}. Pre-populate highway cab transit via Mahatma Gandhi Setu.`
              : leg.layoverReason}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-3 border-t border-dashed border-red-500/10 text-[9px] font-bold">
        {isDifferentStation ? (
          <div className="col-span-2 flex items-center justify-between p-2 rounded-xl bg-orange-500/5 border border-orange-500/10">
            <div>
              <span className="block opacity-60 uppercase font-mono text-[7px] text-orange-500">Cab Directions</span>
              <span className={`block font-black text-[9px] mt-0.5 ${d ? "text-slate-200" : "text-slate-850"}`}>
                Cab ⇄ HJP (45m drive)
              </span>
            </div>
            <a 
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 text-[8.5px] font-black uppercase tracking-wider bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-all flex items-center gap-1 shadow-sm shrink-0 font-mono"
            >
              <span>Map</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        ) : (
          <div className={`p-2 rounded-xl text-left ${d ? "bg-slate-950/40 border border-white/5" : "bg-white border border-slate-200 shadow-sm"}`}>
            <span className="block opacity-60 uppercase font-mono text-[7px]">Platform switch</span>
            <span className={`block font-black text-[9.5px] mt-0.5 ${d ? "text-slate-200" : "text-slate-800"}`}>
              Pf #{fromPlatform} ➜ Pf #{toPlatform}
            </span>
          </div>
        )}

        {!isDifferentStation && (
          <div className={`p-2 rounded-xl text-left ${d ? "bg-slate-950/40 border border-white/5" : "bg-white border border-slate-200 shadow-sm"}`}>
            <span className="block opacity-60 uppercase font-mono text-[7px]">Platforms distance</span>
            <span className={`block font-black text-[9.5px] mt-0.5 ${d ? "text-slate-200" : "text-slate-800"}`}>
              {walkingMinutes}m ({distanceMeters}m)
            </span>
          </div>
        )}

        <div className={`p-2 rounded-xl text-left ${d ? "bg-slate-950/40 border border-white/5" : "bg-white border border-slate-200 shadow-sm"}`}>
          <span className="block opacity-60 uppercase font-mono text-[7px]">Buffer sync</span>
          <span className="block font-black text-[9.5px] mt-0.5 text-emerald-500">
            Lounge Sync OK
          </span>
        </div>

        <div className={`p-2 rounded-xl text-left ${d ? "bg-slate-950/40 border border-white/5" : "bg-white border border-slate-200 shadow-sm"}`}>
          <span className="block opacity-60 uppercase font-mono text-[7px]">Risk Index</span>
          <div className="flex items-center gap-1 mt-0.5">
            <span className={`w-1.5 h-1.5 rounded-full ${
              delayRiskPercentage < 6 ? "bg-emerald-500 animate-pulse" : "bg-amber-500 animate-pulse"
            }`} />
            <span className={`font-black text-[9.5px] ${
              delayRiskPercentage < 6 ? "text-emerald-500" : "text-amber-550"
            }`}>
              {delayRiskPercentage}% Risk
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
