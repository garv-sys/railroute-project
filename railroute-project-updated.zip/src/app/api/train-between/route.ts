import { checkDirectTrains } from '@/services/trainService';
import { trustMetaForTrainList } from '@/lib/confidence';
import { apiFailure, apiSuccess, validationFailure } from '@/lib/api-response';
import { getClientIp, isRateLimited } from '@/lib/rate-limiter';

export async function POST(request: Request) {
  const requestId = `tb_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const ip = getClientIp(request);
  if (isRateLimited(`tb_${ip}`, 30, 60 * 1000)) {
    return apiFailure({
      error: "Too many requests. Please try again later.",
      requestId,
      status: 429,
      provider: "Rate Limiter",
    });
  }
  try {
    const { source, destination, date, classType = 'Any', debug = false } = await request.json();

    if (!source || !destination || !date) {
      return validationFailure('Missing source, destination, or date', requestId);
    }

    const query = {
      source: String(source).toUpperCase().trim(),
      destination: String(destination).toUpperCase().trim(),
      date: String(date),
      classType: String(classType),
    };
    const trains = await checkDirectTrains(
      query.source,
      query.destination,
      query.date,
      query.classType,
      { debug: Boolean(debug), fetchLive: false, exactStationOnly: false, providerPairLimit: 6, plannerLegTimeoutMs: 8000 }
    );

    if (!trains.length) {
      console.warn('[api/train-between] Empty provider result', { requestId, ...query });
    }

    const meta = trustMetaForTrainList(trains);
    return apiSuccess({ requestId, data: { trains }, meta, extra: { trains } });
  } catch (error) {
    console.error('[api/train-between] Error', { requestId, error });
    return apiFailure({ error: 'Internal server error', requestId, provider: 'RailRoute train search API' });
  }
}
