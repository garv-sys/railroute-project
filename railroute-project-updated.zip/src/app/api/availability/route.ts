import { ZodError } from "zod";

import { apiFailure, apiSuccess, validationFailure } from "@/lib/api-response";
import { availabilityReasonForStatus, fareReasonForStatus } from "@/lib/railway-trust";
import { getClientIp, isRateLimited } from "@/lib/rate-limiter";
import { getVerifiedAvailability } from "@/services/availabilityService";

export async function POST(request: Request) {
  const requestId = `avail_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const ip = getClientIp(request);
  if (isRateLimited(`avail_${ip}`, 20, 60 * 1000)) {
    return apiFailure({
      error: "Too many requests. Please try again later.",
      requestId,
      status: 429,
      provider: "Rate Limiter",
    });
  }
	  try {
	    const body = await request.json();
	    const result = await getVerifiedAvailability(body);
	    const debug = body?.debug === true || body?.debug === "true";
	    const availabilityText = result.data.availabilityText ?? availabilityReasonForStatus(
	      result.data.availabilityStatus,
	      result.data.classType,
	      result.data.reason
	    );
	    const row = {
      date: result.data.date,
      availabilityText,
      status: availabilityText,
      source: result.data.exactDate ? "date-specific-provider" : "unavailable",
      reason: result.data.reason,
      seats: result.data.seats,
      fare: result.data.fare,
      availabilityStatus: result.data.availabilityStatus,
      fareStatus: result.data.fareStatus,
      lookupReason: result.data.lookupReason,
      proof: result.data.proof,
    };

    if (!result.data.exactDate) {
      console.warn("[api/availability] Selected-date availability unavailable", {
        requestId,
        trainNo: result.data.trainNo,
        source: result.data.source,
        destination: result.data.destination,
        date: result.data.date,
        classType: result.data.classType,
        quota: result.data.quota,
        reason: result.data.reason,
      });
    }

	    const responseData = {
	      trainNo: result.data.trainNo,
	      source: result.data.source,
	      destination: result.data.destination,
	      date: result.data.date,
	      classType: result.data.classType,
	      quota: result.data.quota,
	      availability: [row],
	      fare: result.data.fare ? { totalFare: result.data.fare } : null,
	      availabilityText,
	      status: result.data.status,
	      seats: result.data.seats,
	      fareSource: result.data.fareSource,
	      exactDate: result.data.exactDate,
	      reason: result.data.reason,
	      availabilityStatus: result.data.availabilityStatus,
	      fareStatus: result.data.fareStatus,
	      lookupReason: result.data.lookupReason,
	      fareWarning: fareReasonForStatus(result.data.fareStatus, result.data.reason),
	      proof: result.data.proof,
	    };

	    return apiSuccess({
	      requestId,
	      data: responseData,
	      meta: result.meta,
	      extra: {
	        provider: result.provider,
	        warning: result.meta.warning,
	        debugTrace: debug ? {
	          providerSource: result.provider,
	          apiEndpoint: `availability:${result.data.trainNo}:${result.data.source}:${result.data.destination}:${result.data.date}:${result.data.classType}:${result.data.quota}`,
	          selectedClass: result.data.classType,
	          providerReturnedClass: result.data.classType,
	          availabilityResponse: result.rawProviderResponse?.data?.availability ?? null,
	          fareResponse: result.rawProviderResponse?.data?.fare ?? null,
	          rawResponse: result.rawProviderResponse,
	          mappedResponse: result.data,
	          renderedResponse: responseData,
	        } : undefined,
	      },
	    });
  } catch (error: any) {
    if (error instanceof ZodError) {
      return validationFailure(error.issues[0]?.message || "Invalid availability request", requestId);
    }
    console.error("[api/availability] Error", { requestId, error });
    return apiFailure({ error: "Internal server error", requestId, provider: "RailRoute availability API" });
  }
}
