import { apiSuccess } from "@/lib/api-response";
import { buildTrustMeta } from "@/lib/confidence";
import { getRailProviderCacheStats } from "@/services/irctcService";

export async function GET() {
  const cache = getRailProviderCacheStats();
  const now = new Date().toISOString();
  const usage = cache.usage;

  return apiSuccess({
    data: {
      cache,
      usage,
      checkedAt: now,
      note: "Operational cache, queue, cooldown and usage status only. This endpoint does not call the railway provider.",
      guardrails: {
        status: usage?.totals?.guarded ? "active" : "clear",
        providerCalls: usage?.totals?.providerCalls || 0,
        guardedCalls: usage?.totals?.guarded || 0,
        failedCalls: usage?.totals?.failures || 0,
      },
    },
    meta: buildTrustMeta({
      source: "live",
      provider: "RailRoute provider health",
      isLive: true,
      asOf: now,
    }),
  });
}
