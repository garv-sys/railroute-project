const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../src/app/book/page.tsx');
let content = fs.readFileSync(filePath, 'utf8');

// Ensure ThemeToggle is imported
if (!content.includes('import { ThemeToggle }')) {
  content = content.replace(/import {([^}]+)} from "lucide-react";/, 'import { ThemeToggle } from "@/components/theme-toggle";\nimport { $1 } from "lucide-react";');
}

// Ensure ThemeToggle is in the navbar
content = content.replace(
  /(<div className="flex items-center gap-6 pr-2">)/,
  '$1\n            <ThemeToggle />'
);

// Map Light mode to dark mode equivalent using Tailwind classes.

// 1. Backgrounds
// bg-slate-50 -> bg-slate-50 dark:bg-[#0a0a0a]
content = content.replace(/bg-slate-50(?! dark:)/g, 'bg-slate-50 dark:bg-[#0a0a0a]');
// bg-white -> bg-white dark:bg-[#121212]
content = content.replace(/bg-white(?! \/| dark:| \")/g, 'bg-white dark:bg-[#121212]');
content = content.replace(/bg-white\/95(?! dark:)/g, 'bg-white/95 dark:bg-[#121212]/95');
content = content.replace(/bg-white\/80(?! dark:)/g, 'bg-white/80 dark:bg-[#121212]/80');
content = content.replace(/bg-slate-100(?! dark:)/g, 'bg-slate-100 dark:bg-[#1a1a1a]');

// 2. Text colors
// text-slate-900 -> text-slate-900 dark:text-white
content = content.replace(/text-slate-900(?! dark:)/g, 'text-slate-900 dark:text-white');
// text-slate-800 -> text-slate-800 dark:text-slate-200
content = content.replace(/text-slate-800(?! dark:)/g, 'text-slate-800 dark:text-slate-200');
// text-slate-700 -> text-slate-700 dark:text-slate-300
content = content.replace(/text-slate-700(?! dark:)/g, 'text-slate-700 dark:text-slate-300');
// text-slate-600 -> text-slate-600 dark:text-slate-400
content = content.replace(/text-slate-600(?! dark:)/g, 'text-slate-600 dark:text-slate-400');
// text-slate-500 -> text-slate-500 dark:text-slate-500
// (No change)

// 3. Borders
// border-slate-200 -> border-slate-200 dark:border-white/10
content = content.replace(/border-slate-200(?! dark:)/g, 'border-slate-200 dark:border-white/10');
// border-slate-300 -> border-slate-300 dark:border-white/20
content = content.replace(/border-slate-300(?! dark:)/g, 'border-slate-300 dark:border-white/20');

// 4. Shadows
// shadow-xl shadow-slate-200/50 -> shadow-xl shadow-slate-200/50 dark:shadow-none
content = content.replace(/shadow-xl shadow-slate-200\/50(?! dark:)/g, 'shadow-xl shadow-slate-200/50 dark:shadow-[0_20px_50px_rgba(0,0,0,0.5)]');
content = content.replace(/shadow-lg shadow-slate-200\/50(?! dark:)/g, 'shadow-lg shadow-slate-200/50 dark:shadow-none');

// 5. Misc fixes for transition and specific components
content = content.replace(/min-h-screen bg-slate-50/g, 'min-h-screen bg-slate-50 transition-colors duration-500');

fs.writeFileSync(filePath, content, 'utf8');
console.log('Migration to add dark classes completed.');
