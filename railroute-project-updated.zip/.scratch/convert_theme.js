const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../src/app/book/page.tsx');
let content = fs.readFileSync(filePath, 'utf8');

// 1. Main Backgrounds
content = content.replace(/bg-gradient-to-b from-\[#060814\] via-\[#0D1226\] to-\[#0A0D1B\]/g, 'bg-slate-50');
content = content.replace(/bg-slate-950\/80/g, 'bg-white');
content = content.replace(/bg-slate-950\/60/g, 'bg-white');
content = content.replace(/bg-slate-950\/70/g, 'bg-white/95');
content = content.replace(/bg-slate-950\/40/g, 'bg-white/80');
content = content.replace(/bg-slate-950/g, 'bg-white');

content = content.replace(/bg-slate-900\/80/g, 'bg-white');
content = content.replace(/bg-slate-900\/60/g, 'bg-white');
content = content.replace(/bg-slate-900\/40/g, 'bg-white');
content = content.replace(/bg-slate-900/g, 'bg-white');

content = content.replace(/bg-slate-800\/50/g, 'bg-slate-100');
content = content.replace(/bg-slate-800\/80/g, 'bg-slate-100');
content = content.replace(/bg-slate-800/g, 'bg-slate-100');
content = content.replace(/bg-slate-850/g, 'bg-slate-50');

// 2. Borders
content = content.replace(/border-slate-800\/90/g, 'border-slate-200');
content = content.replace(/border-slate-800\/80/g, 'border-slate-200');
content = content.replace(/border-slate-800\/40/g, 'border-slate-200');
content = content.replace(/border-slate-800/g, 'border-slate-200');
content = content.replace(/border-slate-850/g, 'border-slate-200');
content = content.replace(/border-slate-700/g, 'border-slate-200');
content = content.replace(/border-white\/10/g, 'border-slate-200');
content = content.replace(/border-white\/20/g, 'border-slate-200');

// 3. Texts
// Order matters! text-slate-100 -> text-slate-900
content = content.replace(/text-slate-100/g, 'text-slate-900');
content = content.replace(/text-slate-200/g, 'text-slate-800');
content = content.replace(/text-slate-300/g, 'text-slate-700');
content = content.replace(/text-slate-350/g, 'text-slate-600');
content = content.replace(/text-slate-355/g, 'text-slate-600');
content = content.replace(/text-slate-400/g, 'text-slate-500');
content = content.replace(/text-slate-500/g, 'text-slate-500'); // stays the same
// White text that isn't inside a colored button needs to be dark
// Careful: text-white inside buttons (like primary blue button) should stay white.
// Let's manually replace `text-white` with `text-slate-900` EXCEPT when next to specific classes.
// Or we can just let `text-white` be and fix the main headers.
content = content.replace(/text-white/g, 'text-slate-900');
// Restore text-white on primary buttons and gradients
content = content.replace(/bg-\[#4A90FF\](.*?)text-slate-900/g, 'bg-[#4A90FF]$1text-white');
content = content.replace(/bg-gradient-to-r from-blue-500(.*?)text-slate-900/g, 'bg-gradient-to-r from-blue-500$1text-white');
content = content.replace(/text-slate-900 font-bold rounded/g, 'text-white font-bold rounded');
content = content.replace(/bg-indigo-600(.*?)text-slate-900/g, 'bg-indigo-600$1text-white');
content = content.replace(/bg-emerald-600(.*?)text-slate-900/g, 'bg-emerald-600$1text-white');
content = content.replace(/<Train className="w-4 h-4 text-slate-900" \/>/g, '<Train className="w-4 h-4 text-white" />');
content = content.replace(/bg-slate-900 hover:bg-slate-800 text-slate-900/g, 'bg-slate-900 hover:bg-slate-800 text-white');


// 4. Glows and Shadows
content = content.replace(/shadow-\[0_20px_50px_rgba\(0,0,0,0\.5\)\]/g, 'shadow-xl shadow-slate-200/50');
content = content.replace(/shadow-\[0_15px_35px_rgba\(0,0,0,0\.4\)\]/g, 'shadow-lg shadow-slate-200/50');
content = content.replace(/drop-shadow-\[0_2px_15px_rgba\(74,144,255,0\.3\)\]/g, 'drop-shadow-sm');
content = content.replace(/shadow-\[0_0_12px_rgba\(74,144,255,0\.4\)\]/g, 'shadow-md');
content = content.replace(/shadow-\[0_0_15px_rgba\(74,144,255,0\.8\)\]/g, 'shadow-sm');
content = content.replace(/shadow-\[0_0_20px_rgba\(74,144,255,0\.25\)\]/g, 'shadow-md');

// 5. Blurs and Ambient Lights (Remove them for light theme)
content = content.replace(/w-\[600px\] h-\[600px\] bg-blue-500\/10 rounded-full blur-\[150px\]/g, 'hidden');
content = content.replace(/w-\[500px\] h-\[500px\] bg-indigo-500\/8 rounded-full blur-\[130px\]/g, 'hidden');
content = content.replace(/w-\[300px\] h-\[300px\] bg-violet-600\/5 rounded-full blur-\[90px\]/g, 'hidden');

// 6. Hovers and Interactions
content = content.replace(/hover:text-white/g, 'hover:text-indigo-600');
content = content.replace(/hover:bg-slate-750/g, 'hover:bg-slate-100');
content = content.replace(/hover:bg-slate-800/g, 'hover:bg-slate-100');

// Write back
fs.writeFileSync(filePath, content, 'utf8');
console.log('Migration script completed.');
