const { checkDirectTrains } = require('./src/services/trainService');

async function run() {
  try {
    if (!process.env.IRCTC_API_KEY) {
      throw new Error('Set IRCTC_API_KEY in .env.local before running this script.');
    }
    const res = await checkDirectTrains('NDLS', 'PNBE', '19-05-2026', 'Any');
    console.log("TOTAL TRAINS:", res.length);
    res.forEach(t => {
      console.log(`- ${t.trainNo}: ${t.trainName} (${t.duration}) - Avail: ${t.availability} - Fare: ${t.fare}`);
    });
  } catch (e) {
    console.error(e);
  }
}
run();
